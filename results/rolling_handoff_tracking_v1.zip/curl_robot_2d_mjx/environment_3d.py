"""Brax-compatible MJX environment for 3-D curl rolling."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from curl_robot_2d.model_3d import JOINT_NAMES_3D
from curl_robot_2d.parameters import (
    FIXED_PARAMETERS,
    PUPPER_ORIGINAL_SHELL_60_PARAMETERS,
    REAL_GEOMETRY_PARAMETERS,
)
from curl_robot_2d_mjx.cem_reference import (
    CEMReferenceGeometry,
    CEMReferenceConfig,
    advance_oscillator,
    load_cem_reference,
    reference_action,
    wrapped_phase_error,
)
from curl_robot_2d_mjx.config_3d import (
    Rolling3DConfig,
    smoothstep_ramp,
    validate_3d_config,
)
from curl_robot_2d_mjx.reward_3d import (
    REWARD_3D_TERM_NAMES,
    Rolling3DRewardConfig,
    conservative_rolling_potential,
    reward_terms_3d,
    stability_error_cost_3d,
)
from curl_robot_2d_mjx.startup_rolling_3d import (
    compose_startup_action_3d,
    reset_pose_arrays_3d,
    residual_elapsed_3d,
    rolling_elapsed_3d,
    stand_startup_action_3d,
)
from curl_robot_2d_mjx.terrain_3d import (
    hfield_data_3d,
    hfield_data_flat_column_major,
    slope_terrain_config_from_task,
    terrain_surface_offset,
    terrain_surface_z_xp,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH_3D = PROJECT_ROOT / "assets" / "curl_robot_3d.xml"
REAL_MODEL_PATH_3D = (
    PROJECT_ROOT / "assets" / "curl_robot_3d_real_geometry.xml"
)
PUPPER_OPEN60_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "curl_robot_3d_pupper_r127p5_open60_width120.xml"
)
ROLLINGQUAD_2_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad.xml"
)
ROLLINGQUAD_2_SIMPLE_CONVEX_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_simple_convex.xml"
)
ROLLINGQUAD_2_PRIMITIVE_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_primitive.xml"
)
ROLLINGQUAD_2_ABD10_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_abd10.xml"
)
ROLLINGQUAD_2_ABD10_NO_SELF_COLLISION_MODEL_PATH_3D = (
    PROJECT_ROOT / "assets" / "rollingquad_description_2" / "mjcf"
    / "rollingquad_abd10_no_self_collision.xml"
)
ROLLINGQUAD_2_PRIMITIVE_ABD10_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_primitive_abd10.xml"
)
ROLLINGQUAD_2_ABD10_TERRAIN_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_abd10_terrain.xml"
)
ROLLINGQUAD_2_PRIMITIVE_ABD10_TERRAIN_MODEL_PATH_3D = (
    PROJECT_ROOT
    / "assets"
    / "rollingquad_description_2"
    / "mjcf"
    / "rollingquad_primitive_abd10_terrain.xml"
)
# Geometries that share the corrected 12-joint RollingQuad CAD contract and
# differ only in collision-surface representation (STL mesh, convex hull, or
# analytic primitives) or in the baked front/rear abduction offset.
ROLLINGQUAD_GEOMETRIES_3D = (
    "rollingquad_2",
    "rollingquad_2_simple_convex",
    "rollingquad_2_primitive",
    "rollingquad_2_abd10",
    "rollingquad_2_abd10_no_self_collision",
    "rollingquad_2_primitive_abd10",
)
# Analytic-primitive collision variants (with or without the baked abduction
# offset).  These use capsule/cylinder/sphere geoms and a capsule-arc shell, so
# they need the primitive-specific torso/foot-shell geom classification below.
PRIMITIVE_ROLLINGQUAD_GEOMETRIES_3D = (
    "rollingquad_2_primitive",
    "rollingquad_2_primitive_abd10",
)
MODEL_PATHS_3D = {
    "baseline": MODEL_PATH_3D,
    "real": REAL_MODEL_PATH_3D,
    "pupper_open60": PUPPER_OPEN60_MODEL_PATH_3D,
    "rollingquad_2": ROLLINGQUAD_2_MODEL_PATH_3D,
    "rollingquad_2_simple_convex": ROLLINGQUAD_2_SIMPLE_CONVEX_MODEL_PATH_3D,
    "rollingquad_2_primitive": ROLLINGQUAD_2_PRIMITIVE_MODEL_PATH_3D,
    "rollingquad_2_abd10": ROLLINGQUAD_2_ABD10_MODEL_PATH_3D,
    "rollingquad_2_abd10_no_self_collision": ROLLINGQUAD_2_ABD10_NO_SELF_COLLISION_MODEL_PATH_3D,
    "rollingquad_2_primitive_abd10": ROLLINGQUAD_2_PRIMITIVE_ABD10_MODEL_PATH_3D,
}
# hfield-floor variants used when the terrain curriculum is enabled.  The
# heights are written at run time from the terrain profile; the baked file only
# fixes the hfield grid so relative mesh references keep resolving.
TERRAIN_MODEL_PATHS_3D = {
    "rollingquad_2_abd10": ROLLINGQUAD_2_ABD10_TERRAIN_MODEL_PATH_3D,
    "rollingquad_2_primitive_abd10": ROLLINGQUAD_2_PRIMITIVE_ABD10_TERRAIN_MODEL_PATH_3D,
}
BASELINE_3D_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "collision_constrained_cem_foot_gap_2mm_short_contact"
    / "best_phase_controller.json"
)
REAL_3D_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "staged_cem_real_geometry_180_d50_foot60"
    / "03_foot_gap_2mm"
    / "best_phase_controller.json"
)
PUPPER_OPEN60_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "pupper_r127p5_open60_shell150_45_three_stage_cem"
    / "03_strict_forbidden_collision"
    / "best_phase_controller.json"
)
ROLLINGQUAD_2_CEM_CONTROLLER = (
    PROJECT_ROOT / "assets" / "rollingquad_2_3d_self_collision_cem_reference.json"
)
ROLLINGQUAD_2_SIMPLE_CONVEX_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "simple_convex_warmstart_cem"
    / "03_strict_10s"
    / "best_phase_controller.json"
)
ROLLINGQUAD_2_PRIMITIVE_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "rollingquad_primitive_stiff_cem"
    / "03_strict_10s"
    / "best_phase_controller.json"
)
ROLLINGQUAD_2_ABD10_HIGH_SPEED_CEM_CONTROLLER = (
    PROJECT_ROOT
    / "results"
    / "rollingquad_abd10_high_speed_zero_contact_refine_smoke"
    / "01_zero_contact_speed_refine"
    / "best_phase_controller.json"
)
CEM_CONTROLLER_PATHS_3D = {
    "baseline": BASELINE_3D_CEM_CONTROLLER,
    "real": REAL_3D_CEM_CONTROLLER,
    "pupper_open60": PUPPER_OPEN60_CEM_CONTROLLER,
    "rollingquad_2": ROLLINGQUAD_2_CEM_CONTROLLER,
    "rollingquad_2_simple_convex": ROLLINGQUAD_2_SIMPLE_CONVEX_CEM_CONTROLLER,
    "rollingquad_2_primitive": ROLLINGQUAD_2_PRIMITIVE_CEM_CONTROLLER,
    # Canonical abd10 full-geometry controller: smoke speed refinement of the
    # zero-contact reference. Abduction still comes from the compact keyframe.
    "rollingquad_2_abd10": ROLLINGQUAD_2_ABD10_HIGH_SPEED_CEM_CONTROLLER,
    "rollingquad_2_abd10_no_self_collision": ROLLINGQUAD_2_ABD10_HIGH_SPEED_CEM_CONTROLLER,
    "rollingquad_2_primitive_abd10": ROLLINGQUAD_2_PRIMITIVE_CEM_CONTROLLER,
}
DEFAULT_3D_CEM_CONTROLLER = ROLLINGQUAD_2_CEM_CONTROLLER
ACTION_SIZE_3D = 8
OBSERVATION_SIZE_3D = 65
PHASE_FEEDBACK_SIZE_3D = 4
PLANAR_ACTION_SCALES = np.asarray((0.8, 1.2, 0.8, 1.2), dtype=np.float64)
PLANAR_COMPACT = np.asarray(
    (
        FIXED_PARAMETERS.compact_hip_angle,
        FIXED_PARAMETERS.compact_knee_angle,
        FIXED_PARAMETERS.compact_hip_angle,
        FIXED_PARAMETERS.compact_knee_angle,
    ),
    dtype=np.float64,
)
PLANAR_JOINT_LOW = np.asarray(
    (
        FIXED_PARAMETERS.hip.shell_compatible_range[0],
        FIXED_PARAMETERS.knee.shell_compatible_range[0],
        FIXED_PARAMETERS.hip.shell_compatible_range[0],
        FIXED_PARAMETERS.knee.shell_compatible_range[0],
    ),
    dtype=np.float64,
)
PLANAR_JOINT_HIGH = np.asarray(
    (
        FIXED_PARAMETERS.hip.shell_compatible_range[1],
        FIXED_PARAMETERS.knee.shell_compatible_range[1],
        FIXED_PARAMETERS.hip.shell_compatible_range[1],
        FIXED_PARAMETERS.knee.shell_compatible_range[1],
    ),
    dtype=np.float64,
)


# Measured target-scale -> mean forward speed for the high-speed reference
# results/rollingquad_abd10_high_speed_zero_contact_refine_smoke/
#     01_zero_contact_speed_refine/best_phase_controller.json
# (10 s scans, kp=5 kd=0.1 torque_limit=3, front -10 deg / rear +10 deg).
# A forward-velocity command (v_cmd) is mapped to the reference target scale by
# inverting this monotonic curve. Below ~0.36 scale the oscillator unlocks and
# the robot rolls backward, and above 1.00 it self-collides, so the usable
# forward speed range is roughly 0.41-0.81 m/s.
FORWARD_COMMAND_LOOKUP_SPEEDS_M_S = (
    0.4111, 0.4256, 0.4382, 0.4546, 0.4692, 0.5250, 0.5789, 0.6321,
    0.6779, 0.7118, 0.7461, 0.7664, 0.7793, 0.7918, 0.8037, 0.8095,
    0.8110,
)
FORWARD_COMMAND_LOOKUP_SCALES = (
    0.36, 0.37, 0.38, 0.39, 0.40, 0.45, 0.50, 0.55,
    0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95,
    1.00,
)
FORWARD_COMMAND_MIN_SCALE = FORWARD_COMMAND_LOOKUP_SCALES[0]
FORWARD_COMMAND_MAX_SCALE = FORWARD_COMMAND_LOOKUP_SCALES[-1]


def forward_command_to_target_scale_3d(xp, v_cmd):
    """Map a forward-velocity command (m/s) to the reference target scale."""

    speeds = xp.asarray(FORWARD_COMMAND_LOOKUP_SPEEDS_M_S)
    scales = xp.asarray(FORWARD_COMMAND_LOOKUP_SCALES)
    scale = xp.interp(v_cmd, speeds, scales)
    return xp.clip(scale, FORWARD_COMMAND_MIN_SCALE, FORWARD_COMMAND_MAX_SCALE)


def steering_prior_3d(
    xp,
    yaw_rate_command,
    k_turn,
    prior_clip,
    *,
    residual_gain=1.0,
    differential_scale=1.0,
):
    """Constant differential steering prior from a yaw-rate command.

    The validated differential pattern is [front_hip, front_knee, rear_hip,
    rear_knee] = [a, a, a, -a] with the left/right sides getting opposite
    signs. In actuator order this is [a, a, -a, -a, a, -a, -a, a]. It is a
    small guidance prior, not a fixed controller: the policy residual fine
    tunes it.
    """

    raw_a = xp.clip(k_turn * yaw_rate_command, -prior_clip, prior_clip)
    a = residual_gain * differential_scale * raw_a
    return xp.stack((a, a, -a, -a, a, -a, -a, a), axis=-1)


def _rolling_observation_mirror_contract_3d():
    width = OBSERVATION_SIZE_3D + PHASE_FEEDBACK_SIZE_3D
    permutation = list(range(width))
    signs = [1.0] * width

    signs[1] = -1.0  # cross-track error
    signs[2] = -1.0  # rolling-axis heading
    signs[3:6] = (-1.0, 1.0, -1.0)  # torso local y axis
    signs[6:9] = (1.0, -1.0, 1.0)  # torso local z axis
    signs[9:12] = (1.0, -1.0, 1.0)  # root linear velocity
    signs[12:15] = (-1.0, 1.0, -1.0)  # root angular velocity
    signs[60] = -1.0  # lateral velocity command
    signs[61] = 1.0  # forward velocity command (reflection-even)
    signs[62] = -1.0  # turning (yaw-rate) command (reflection-odd)
    signs[63] = -1.0  # measured heading rate (reflection-odd)
    signs[64] = 1.0  # rolling-axis elevation (reflection-even)

    pair_permutation = (2, 3, 0, 1, 6, 7, 4, 5)
    for start in (15, 23, 31, 47):
        permutation[start : start + ACTION_SIZE_3D] = tuple(
            start + index for index in pair_permutation
        )
    return tuple(permutation), tuple(signs)


(
    ROLLING_OBSERVATION_MIRROR_PERMUTATION_3D,
    ROLLING_OBSERVATION_MIRROR_SIGNS_3D,
) = _rolling_observation_mirror_contract_3d()


def mirror_rolling_observation_3d(xp, observation):
    """Reflect a rolling observation across the global x-z plane."""

    width = observation.shape[-1]
    valid_widths = (
        OBSERVATION_SIZE_3D,
        OBSERVATION_SIZE_3D + PHASE_FEEDBACK_SIZE_3D,
    )
    if width not in valid_widths:
        raise ValueError(
            f"rolling observation width must be one of {valid_widths}, "
            f"got {width}"
        )
    permutation = xp.asarray(
        ROLLING_OBSERVATION_MIRROR_PERMUTATION_3D[:width]
    )
    signs = xp.asarray(ROLLING_OBSERVATION_MIRROR_SIGNS_3D[:width])
    return xp.take(observation, permutation, axis=-1) * signs


def geometry_parameters_3d(name: str):
    if name == "baseline":
        return FIXED_PARAMETERS
    if name == "real":
        return REAL_GEOMETRY_PARAMETERS
    if name in ("pupper_open60", *ROLLINGQUAD_GEOMETRIES_3D):
        return PUPPER_ORIGINAL_SHELL_60_PARAMETERS
    raise ValueError(f"unknown 3-D geometry: {name!r}")


def model_path_3d(name: str) -> Path:
    try:
        return MODEL_PATHS_3D[name]
    except KeyError as exc:
        raise ValueError(f"unknown 3-D geometry: {name!r}") from exc


def cem_controller_path_3d(name: str) -> Path:
    """Return the CEM reference optimized for the selected geometry."""

    try:
        return CEM_CONTROLLER_PATHS_3D[name]
    except KeyError as exc:
        raise ValueError(f"unknown 3-D geometry: {name!r}") from exc


def terrain_model_path_3d(name: str) -> Path:
    """Return the hfield-floor model for a terrain-enabled geometry."""

    try:
        return TERRAIN_MODEL_PATHS_3D[name]
    except KeyError as exc:
        raise ValueError(
            f"geometry {name!r} has no baked terrain model; terrain is only "
            "supported for the rollingquad_2_abd10 geometries"
        ) from exc


def configure_pupper_shell_collisions_3d(model, *, enabled: bool) -> None:
    """Switch the Pupper's generated rolling shell between physical and visual."""

    contype, conaffinity = (4, 3) if enabled else (0, 0)
    for geom_id in range(model.ngeom):
        name = model.geom(geom_id).name or ""
        if "_shell_" in name:
            model.geom_contype[geom_id] = contype
            model.geom_conaffinity[geom_id] = conaffinity


def disable_rollingquad_self_collision_3d(model) -> None:
    """Set every robot geom to collide with the floor only.

    This drops the selective self-collision whitelist so the full CAD mesh can
    be used without the expensive mesh-vs-mesh self-contact pairs.  It must be
    called only after :func:`validate_rolling_morphology_3d` has confirmed the
    original whitelist contract.
    """

    for geom_id in range(model.ngeom):
        if int(model.geom_bodyid[geom_id]) != 0:
            model.geom_contype[geom_id] = 0
            model.geom_conaffinity[geom_id] = 1


ROLLINGQUAD_SELF_COLLISION_MASKS_3D = {
    "torso_mesh": (16, 7),
    "front_left_hip_link_geom": (2, 29),
    "front_left_thigh_geom": (2, 29),
    "front_right_hip_link_geom": (2, 29),
    "front_right_thigh_geom": (2, 29),
    "rear_left_hip_link_geom": (4, 27),
    "rear_left_thigh_geom": (4, 27),
    "rear_right_hip_link_geom": (4, 27),
    "rear_right_thigh_geom": (4, 27),
    "front_left_foot_proxy": (8, 15),
    "front_right_foot_proxy": (8, 15),
    "rear_left_foot_proxy": (8, 15),
    "rear_right_foot_proxy": (8, 15),
}
# Primitive-collision variant: the torso shell becomes a capsule arc and each
# thigh splits into a link capsule + hip-motor cylinder while each lower leg
# splits into a shank capsule + foot sphere.  Leg masks stay identical to the
# mesh model so the selective ABI (front/rear leg, leg-torso, foot-leg,
# foot-foot) is preserved.
SHELL_MASK_3D = (16, 7)
ROLLINGQUAD_PRIMITIVE_LEG_MASKS_3D = {
    "front_left_hip_link_geom": (2, 29),
    "front_right_hip_link_geom": (2, 29),
    "rear_left_hip_link_geom": (4, 27),
    "rear_right_hip_link_geom": (4, 27),
    "front_left_thigh_geom": (2, 29),
    "front_left_thigh_motor": (2, 29),
    "front_right_thigh_geom": (2, 29),
    "front_right_thigh_motor": (2, 29),
    "rear_left_thigh_geom": (4, 27),
    "rear_left_thigh_motor": (4, 27),
    "rear_right_thigh_geom": (4, 27),
    "rear_right_thigh_motor": (4, 27),
    "front_left_foot_proxy": (8, 15),
    "front_left_shank_geom": (8, 15),
    "front_right_foot_proxy": (8, 15),
    "front_right_shank_geom": (8, 15),
    "rear_left_foot_proxy": (8, 15),
    "rear_left_shank_geom": (8, 15),
    "rear_right_foot_proxy": (8, 15),
    "rear_right_shank_geom": (8, 15),
}
SELF_COLLISION_MASKS_BY_GEOMETRY_3D = {
    "rollingquad_2": ROLLINGQUAD_SELF_COLLISION_MASKS_3D,
    "rollingquad_2_simple_convex": ROLLINGQUAD_SELF_COLLISION_MASKS_3D,
    "rollingquad_2_primitive": ROLLINGQUAD_PRIMITIVE_LEG_MASKS_3D,
    "rollingquad_2_abd10": ROLLINGQUAD_SELF_COLLISION_MASKS_3D,
    "rollingquad_2_primitive_abd10": ROLLINGQUAD_PRIMITIVE_LEG_MASKS_3D,
}
ROLLINGQUAD_FRONT_LEG_GEOM_NAMES_3D = (
    "front_left_hip_link_geom",
    "front_left_thigh_geom",
    "front_right_hip_link_geom",
    "front_right_thigh_geom",
)
ROLLINGQUAD_REAR_LEG_GEOM_NAMES_3D = (
    "rear_left_hip_link_geom",
    "rear_left_thigh_geom",
    "rear_right_hip_link_geom",
    "rear_right_thigh_geom",
)


def _expected_rollingquad_geom_mask(name: str):
    """Return the required (contype, conaffinity) for a RollingQuad geom name."""

    if name in ("torso_mesh", "torso_box_proxy") or "_shell_" in name:
        return SHELL_MASK_3D
    if any(
        suffix in name
        for suffix in ("_hip_link_geom", "_thigh_geom", "_thigh_motor")
    ):
        return (2, 29) if "front" in name else (4, 27)
    if "_foot_proxy" in name or "_shank_geom" in name:
        return (8, 15)
    return None


def detect_rollingquad_geometry_3d(model) -> str | None:
    """Return the RollingQuad geometry whose collision contract matches ``model``."""

    actual = {
        model.geom(geom_id).name
        for geom_id in range(model.ngeom)
        if int(model.geom_bodyid[geom_id]) != 0
    }
    if actual == set(ROLLINGQUAD_SELF_COLLISION_MASKS_3D):
        return "rollingquad_2"
    leg_names = {
        name
        for name in actual
        if "_shell_" not in name and name != "torso_box_proxy"
    }
    if leg_names == set(ROLLINGQUAD_PRIMITIVE_LEG_MASKS_3D):
        return "rollingquad_2_primitive"
    return None


def validate_rollingquad_self_collision_contract_3d(model, geometry=None) -> None:
    """Require the selective CAD self-collision ABI used by ROLL training."""

    if geometry is None:
        geometry = detect_rollingquad_geometry_3d(model)
    if geometry not in SELF_COLLISION_MASKS_BY_GEOMETRY_3D:
        raise ValueError(
            "model collision geoms do not match any rollingquad "
            "self-collision contract"
        )

    actual_names = {
        model.geom(geom_id).name
        for geom_id in range(model.ngeom)
        if int(model.geom_bodyid[geom_id]) != 0
    }
    leg_names = {
        name
        for name in actual_names
        if "_shell_" not in name and name != "torso_box_proxy"
    }
    expected_leg_names = set(SELF_COLLISION_MASKS_BY_GEOMETRY_3D[geometry])
    if leg_names != expected_leg_names:
        raise ValueError(
            f"{geometry} collision geoms do not match the selective "
            "self-collision contract"
        )

    for name in actual_names:
        geom_id = model.geom(name).id
        actual = (
            int(model.geom_contype[geom_id]),
            int(model.geom_conaffinity[geom_id]),
        )
        expected = _expected_rollingquad_geom_mask(name)
        if expected is None:
            raise ValueError(f"unexpected collision geom: {name}")
        if actual != expected:
            raise ValueError(
                f"{geometry} collision mask mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )

    floor_id = model.geom("floor").id
    if (
        int(model.geom_contype[floor_id]),
        int(model.geom_conaffinity[floor_id]),
    ) != (1, 0):
        raise ValueError(f"{geometry} floor collision mask must be (1, 0)")


def validate_rollingquad_no_self_collision_contract_3d(model, geometry) -> None:
    """Require robot-floor contact while rejecting every robot self-contact."""

    floor_id = model.geom("floor").id
    if (
        int(model.geom_contype[floor_id]),
        int(model.geom_conaffinity[floor_id]),
    ) != (1, 0):
        raise ValueError(f"{geometry} floor collision mask must be (1, 0)")

    for geom_id in range(model.ngeom):
        if int(model.geom_bodyid[geom_id]) == 0:
            continue
        actual = (
            int(model.geom_contype[geom_id]),
            int(model.geom_conaffinity[geom_id]),
        )
        if actual != (0, 1):
            name = model.geom(geom_id).name
            raise ValueError(
                f"{geometry} no-self-collision mask mismatch for {name}: "
                f"expected (0, 1), got {actual}"
            )

    for pair_id in range(model.npair):
        geom1 = int(model.pair_geom1[pair_id])
        geom2 = int(model.pair_geom2[pair_id])
        if (
            int(model.geom_bodyid[geom1]) != 0
            and int(model.geom_bodyid[geom2]) != 0
        ):
            raise ValueError(
                f"{geometry} contains an explicit robot self-collision pair"
            )


def configure_floor_contact_friction_3d(
    model,
    *,
    floor_geom_id: int,
    friction_scale: float,
) -> None:
    """Make floor friction authoritative without changing nominal contacts."""

    floor_contype = int(model.geom_contype[floor_geom_id])
    floor_conaffinity = int(model.geom_conaffinity[floor_geom_id])
    floor_body_id = int(model.geom_bodyid[floor_geom_id])
    peer_ids = []
    for geom_id in range(model.ngeom):
        if geom_id == floor_geom_id:
            continue
        if int(model.geom_bodyid[geom_id]) == floor_body_id:
            continue
        peer_contype = int(model.geom_contype[geom_id])
        peer_conaffinity = int(model.geom_conaffinity[geom_id])
        if (
            floor_contype & peer_conaffinity
            or peer_contype & floor_conaffinity
        ):
            peer_ids.append(geom_id)
    if not peer_ids:
        raise ValueError("floor has no dynamically generated contact peers")

    for pair_id in range(model.npair):
        if floor_geom_id in (
            int(model.pair_geom1[pair_id]),
            int(model.pair_geom2[pair_id]),
        ):
            raise ValueError(
                "floor friction override does not support explicit floor pairs"
            )

    floor_priority = int(model.geom_priority[floor_geom_id])
    floor_solmix = float(model.geom_solmix[floor_geom_id])
    floor_solref = model.geom_solref[floor_geom_id].copy()
    floor_solimp = model.geom_solimp[floor_geom_id].copy()
    floor_friction = model.geom_friction[floor_geom_id].copy()
    effective = []
    for geom_id in peer_ids:
        peer_priority = int(model.geom_priority[geom_id])
        peer_solmix = float(model.geom_solmix[geom_id])
        peer_solref = model.geom_solref[geom_id]
        if peer_priority != floor_priority:
            raise ValueError(
                "floor friction override requires equal nominal geom priorities"
            )
        if min(floor_solmix, peer_solmix) <= 0.0:
            raise ValueError(
                "floor friction override requires positive nominal solmix"
            )
        if min(float(floor_solref[0]), float(peer_solref[0])) <= 0.0:
            raise ValueError(
                "floor friction override requires standard positive solref"
            )
        mix = floor_solmix / (floor_solmix + peer_solmix)
        effective.append(
            (
                max(
                    int(model.geom_condim[floor_geom_id]),
                    int(model.geom_condim[geom_id]),
                ),
                mix * floor_solref + (1.0 - mix) * peer_solref,
                mix * floor_solimp
                + (1.0 - mix) * model.geom_solimp[geom_id],
                np.maximum(floor_friction, model.geom_friction[geom_id]),
            )
        )

    condim, solref, solimp, friction = effective[0]
    for peer_condim, peer_solref, peer_solimp, peer_friction in effective[1:]:
        if (
            peer_condim != condim
            or not np.allclose(peer_solref, solref, rtol=0.0, atol=1.0e-12)
            or not np.allclose(peer_solimp, solimp, rtol=0.0, atol=1.0e-12)
            or not np.allclose(
                peer_friction, friction, rtol=0.0, atol=1.0e-12
            )
        ):
            raise ValueError(
                "floor contact peers do not share one nominal contact model"
            )
    geom_adhesion = getattr(model, "geom_adhesion", None)
    if geom_adhesion is not None and (
        np.any(geom_adhesion[peer_ids]) or geom_adhesion[floor_geom_id]
    ):
        raise ValueError("floor friction override does not support adhesion")

    # Higher priority makes low floor-friction scales effective.  Writing the
    # old mixed parameters back to floor keeps scale=1 nominally equivalent.
    model.geom_priority[floor_geom_id] = floor_priority + 1
    model.geom_condim[floor_geom_id] = condim
    model.geom_solref[floor_geom_id] = solref
    model.geom_solimp[floor_geom_id] = solimp
    model.geom_friction[floor_geom_id] = friction * friction_scale


FOOT_GEOM_NAMES_3D = (
    "front_left_foot_proxy",
    "front_right_foot_proxy",
    "rear_left_foot_proxy",
    "rear_right_foot_proxy",
)
PUPPER_JOINT_NAMES_3D = tuple(
    f"{leg}_{joint}"
    for leg in ("front_left", "front_right", "rear_left", "rear_right")
    for joint in ("hip_abduction", "hip", "knee")
)


def validate_rolling_morphology_3d(model, geometry: str) -> None:
    """Reject a model whose joint/actuator contract cannot drive rolling."""

    import mujoco

    if geometry == "rollingquad_2_abd10_no_self_collision":
        validate_rollingquad_no_self_collision_contract_3d(model, geometry)
    elif geometry in ROLLINGQUAD_GEOMETRIES_3D:
        validate_rollingquad_self_collision_contract_3d(model, geometry)
    expected_names = (
        PUPPER_JOINT_NAMES_3D
        if geometry in ("pupper_open60", *ROLLINGQUAD_GEOMETRIES_3D)
        else JOINT_NAMES_3D
    )
    if model.nu != len(expected_names):
        raise ValueError(
            f"{geometry} rolling model has {model.nu} actuators; "
            f"expected {len(expected_names)}"
        )
    for joint_name in expected_names:
        joint_id = mujoco.mj_name2id(
            model, mujoco.mjtObj.mjOBJ_JOINT, joint_name
        )
        actuator_id = mujoco.mj_name2id(
            model, mujoco.mjtObj.mjOBJ_ACTUATOR, f"{joint_name}_servo"
        )
        if min(joint_id, actuator_id) < 0:
            raise ValueError(f"incomplete rolling joint/actuator: {joint_name}")
        if int(model.actuator_trnid[actuator_id, 0]) != joint_id:
            raise ValueError(
                f"rolling actuator is bound to the wrong joint: {joint_name}_servo"
            )


def rolling_target_ctrl_3d(
    xp,
    compact_ctrl,
    actuator_ids,
    action,
    action_scales,
    joint_low,
    joint_high,
):
    """Embed the eight rolling targets in either an 8- or 12-actuator model."""

    controlled_target = xp.clip(
        compact_ctrl[actuator_ids] + action * action_scales,
        joint_low,
        joint_high,
    )
    if hasattr(compact_ctrl, "at"):
        return compact_ctrl.at[actuator_ids].set(controlled_target)
    target = compact_ctrl.copy()
    target[actuator_ids] = controlled_target
    return target


def duplicate_planar_action_3d(xp, planar_action):
    """Map front/rear 2-D normalized actions to left/right 3-D rails."""

    front_hip, front_knee, rear_hip, rear_knee = planar_action
    return xp.stack(
        (
            front_hip,
            front_knee,
            front_hip,
            front_knee,
            rear_hip,
            rear_knee,
            rear_hip,
            rear_knee,
        )
    )


def rolling_axis_heading_3d(xp, body_y_axis):
    """Return heading from the roll-invariant horizontal rolling axis."""

    return xp.arctan2(-body_y_axis[..., 0], body_y_axis[..., 1])


def rolling_axis_stability_tilt_3d(xp, body_y_axis, yaw_command, *, calibrated=False):
    """Calibrated turns may rotate horizontally without being treated as falls."""
    legacy = xp.arccos(xp.clip(xp.abs(body_y_axis[..., 1]), 0., 1.))
    if not calibrated:
        return legacy
    elevation = xp.arcsin(xp.clip(xp.abs(body_y_axis[..., 2]), 0., 1.))
    return xp.where(xp.abs(yaw_command) > 1e-3, elevation, legacy)


def pair_coupled_residual_action_3d(
    xp,
    raw_action,
    differential_scale,
):
    """Map common/differential channels into actuator-ordered residuals."""

    if differential_scale is None:
        return raw_action
    common = raw_action[:4]
    differential = differential_scale * raw_action[4:]
    front_hip, front_knee, rear_hip, rear_knee = common
    front_hip_diff, front_knee_diff, rear_hip_diff, rear_knee_diff = (
        differential
    )
    return xp.clip(
        xp.stack(
            (
                front_hip + front_hip_diff,
                front_knee + front_knee_diff,
                front_hip - front_hip_diff,
                front_knee - front_knee_diff,
                rear_hip + rear_hip_diff,
                rear_knee + rear_knee_diff,
                rear_hip - rear_hip_diff,
                rear_knee - rear_knee_diff,
            )
        ),
        -1.0,
        1.0,
    )


def pair_coupled_reset_noise_3d(
    xp,
    common_noise,
    differential_noise,
    differential_scale,
):
    """Map four common and differential reset samples to eight joints."""

    differential = differential_scale * differential_noise
    front_hip, front_knee, rear_hip, rear_knee = common_noise
    front_hip_diff, front_knee_diff, rear_hip_diff, rear_knee_diff = (
        differential
    )
    return xp.stack(
        (
            front_hip + front_hip_diff,
            front_knee + front_knee_diff,
            front_hip - front_hip_diff,
            front_knee - front_knee_diff,
            rear_hip + rear_hip_diff,
            rear_knee + rear_knee_diff,
            rear_hip - rear_hip_diff,
            rear_knee - rear_knee_diff,
        )
    )


def axis_tilted_quaternion_3d(xp, base_quaternion, tilt_x, tilt_z):
    """Apply a small x/z rotation-vector perturbation to a quaternion."""

    angle = xp.sqrt(tilt_x * tilt_x + tilt_z * tilt_z)
    half_angle = 0.5 * angle
    vector_scale = xp.where(
        angle > 1e-8,
        xp.sin(half_angle) / xp.maximum(angle, 1e-8),
        0.5,
    )
    delta = xp.asarray(
        (
            xp.cos(half_angle),
            tilt_x * vector_scale,
            xp.zeros_like(angle),
            tilt_z * vector_scale,
        )
    )
    aw, ax, ay, az = delta
    bw, bx, by, bz = base_quaternion
    quaternion = xp.asarray(
        (
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        )
    )
    return quaternion / xp.linalg.norm(quaternion)


def phase_feedback_observation_3d(
    xp,
    rolling_phase,
    oscillator_phase,
):
    """Encode actual rolling phase and phase-lock error without wrap jumps."""

    phase_error = wrapped_phase_error(
        xp, rolling_phase, oscillator_phase
    )
    return xp.asarray(
        (
            xp.sin(rolling_phase),
            xp.cos(rolling_phase),
            xp.sin(phase_error),
            xp.cos(phase_error),
        )
    )


def reference_startup_scale_3d(
    xp,
    elapsed_s,
    task: Rolling3DConfig,
    target_scale=None,
):
    ramp = smoothstep_ramp(
        xp,
        elapsed_s,
        task.reference_ramp_duration_s,
    )
    effective_target = (
        task.reference_action_scale if target_scale is None else target_scale
    )
    start_scale = (
        effective_target
        if task.reference_ramp_start_scale is None
        else task.reference_ramp_start_scale
    )
    ramped_scale = start_scale + (
        effective_target - start_scale
    ) * ramp
    boost_decay = 1.0 - smoothstep_ramp(
        xp,
        elapsed_s,
        task.reference_startup_boost_duration_s,
    )
    return ramped_scale * (
        1.0 + task.reference_startup_boost * boost_decay
    )


def rolling_ramp_3d(xp, elapsed_s, task: Rolling3DConfig):
    """Smooth 0->1 gate that only opens after the rolling phase starts.

    Used to keep the steering prior off during a stand startup (and at reset)
    so it cannot tilt the robot before rolling begins.
    """

    return smoothstep_ramp(
        xp,
        rolling_elapsed_3d(xp, elapsed_s, task),
        task.reference_ramp_duration_s,
    )


def advance_rolling_phase_3d(
    xp,
    rolling_phase,
    local_y_angular_velocity,
    timestep,
):
    """Integrate signed spin around the torso's local rolling axis."""

    return rolling_phase + timestep * local_y_angular_velocity


def apply_physics_options_3d(model, task: Rolling3DConfig) -> None:
    """Apply a runtime solver profile to the generated 3-D MuJoCo model."""

    import mujoco

    solver_values = {
        "newton": mujoco.mjtSolver.mjSOL_NEWTON,
        "cg": mujoco.mjtSolver.mjSOL_CG,
        "pgs": mujoco.mjtSolver.mjSOL_PGS,
    }
    integrator_values = {
        "euler": mujoco.mjtIntegrator.mjINT_EULER,
        "implicitfast": mujoco.mjtIntegrator.mjINT_IMPLICITFAST,
    }
    cone_values = {
        "pyramidal": mujoco.mjtCone.mjCONE_PYRAMIDAL,
        "elliptic": mujoco.mjtCone.mjCONE_ELLIPTIC,
    }
    jacobian_values = {
        "dense": mujoco.mjtJacobian.mjJAC_DENSE,
        "sparse": mujoco.mjtJacobian.mjJAC_SPARSE,
        "auto": mujoco.mjtJacobian.mjJAC_AUTO,
    }
    model.opt.solver = solver_values[task.solver_name]
    model.opt.integrator = integrator_values[task.integrator_name]
    model.opt.cone = cone_values[task.cone_name]
    model.opt.jacobian = jacobian_values[task.jacobian_name]
    model.opt.timestep = task.physics_timestep
    model.opt.iterations = task.solver_iterations
    model.opt.ls_iterations = task.solver_ls_iterations
    model.geom_friction[:] *= task.geom_friction_scale
    if (
        task.floor_contact_friction_override
        or task.floor_friction_scale != 1.0
    ):
        floor_geom_id = mujoco.mj_name2id(
            model, mujoco.mjtObj.mjOBJ_GEOM, "floor"
        )
        if floor_geom_id < 0:
            raise ValueError("missing MuJoCo geom: floor")
        configure_floor_contact_friction_3d(
            model,
            floor_geom_id=int(floor_geom_id),
            friction_scale=task.floor_friction_scale,
        )
    for body_id in range(1, model.nbody):
        body_name = mujoco.mj_id2name(
            model, mujoco.mjtObj.mjOBJ_BODY, body_id
        )
        side_scale = 1.0
        name_parts = body_name.split("_") if body_name else ()
        if "left" in name_parts:
            side_scale = task.body_mass_left_scale
        elif "right" in name_parts:
            side_scale = task.body_mass_right_scale
        scale = task.body_mass_scale * side_scale
        model.body_mass[body_id] *= scale
        model.body_inertia[body_id] *= scale
    model.actuator_gainprm[:, 0] *= task.actuator_gain_scale
    for actuator_id in range(model.nu):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, actuator_id) or ""
        if name.endswith(("_hip_servo", "_knee_servo")):
            model.actuator_gainprm[actuator_id, 0] *= task.rolling_hip_knee_kp_scale
    model.actuator_biasprm[:, 1] = -model.actuator_gainprm[:, 0]
    if task.disable_root_damping:
        root_id = mujoco.mj_name2id(
            model, mujoco.mjtObj.mjOBJ_JOINT, "root"
        )
        if root_id < 0:
            raise ValueError("missing MuJoCo freejoint: root")
        dof_id = int(model.jnt_dofadr[root_id])
        model.dof_damping[dof_id : dof_id + 6] = 0.0


def _load_dependencies_3d():
    try:
        import jax
        import jax.numpy as jp
        import mujoco
        from brax.envs.base import Env, State
        from mujoco import mjx
    except ImportError as exc:
        raise RuntimeError(
            "3-D MJX dependencies are unavailable. Install "
            "requirements-mjx.txt on the Linux GPU instance."
        ) from exc
    return jax, jp, mujoco, mjx, Env, State


def make_brax_env_3d(
    config: Rolling3DConfig | None = None,
    *,
    reward_config: Rolling3DRewardConfig | None = None,
    cem_reference: CEMReferenceConfig | None = None,
    seed: int = 0,
):
    """Create the first 3-D curl MJX env.

    The default is a CEM-reference residual task: zero residual exactly tracks
    the duplicated left/right 2-D CEM reference.
    """

    task = config or Rolling3DConfig()
    validate_3d_config(task)
    jax, jp, mujoco, mjx, Env, State = _load_dependencies_3d()
    reward_settings = reward_config or Rolling3DRewardConfig()
    reference_settings = cem_reference or load_cem_reference(
        cem_controller_path_3d(task.geometry)
    )
    steering_table = None
    if task.steering_calibration_path:
        from curl_robot_2d_mjx.steering_calibration import (
            load_steering_calibration, calibrated_steering_prior,
        )
        steering_table = load_steering_calibration(
            task.steering_calibration_path, task=task,
            reference=reference_settings, model_path=model_path_3d(task.geometry),
        )

    class CurlRobot3DMJXEnv(Env):
        def __init__(self):
            self.config = task
            self.reward_config = reward_settings
            self.cem_reference = reference_settings
            self.seed = seed
            self.geometry_parameters = geometry_parameters_3d(task.geometry)
            self.terrain_config = (
                slope_terrain_config_from_task(task)
                if task.terrain_enabled
                else None
            )
            self.model_path = (
                terrain_model_path_3d(task.geometry)
                if task.terrain_enabled
                else model_path_3d(task.geometry)
            )
            self.reference_geometry = CEMReferenceGeometry(
                torso_length_m=self.geometry_parameters.torso_length,
                link_length_m=self.geometry_parameters.edge_length,
                foot_diameter_m=2.0 * self.geometry_parameters.foot_radius,
                upper_link_length_m=self.geometry_parameters.upper_length,
                lower_link_length_m=self.geometry_parameters.lower_length,
            )
            self.mj_model = mujoco.MjModel.from_xml_path(str(self.model_path))
            if task.geometry == "pupper_open60":
                configure_pupper_shell_collisions_3d(
                    self.mj_model, enabled=True
                )
            validate_rolling_morphology_3d(self.mj_model, task.geometry)
            apply_physics_options_3d(self.mj_model, task)
            if (
                task.geometry in ROLLINGQUAD_GEOMETRIES_3D
                and not task.self_collision_enabled
            ):
                # Validate the whitelist first, then drop mesh self-collision
                # so the full CAD model runs without mesh-vs-mesh contact pairs.
                disable_rollingquad_self_collision_3d(self.mj_model)
            self.terrain_surface_offset = (
                terrain_surface_offset(self.terrain_config)
                if self.terrain_config is not None
                else 0.0
            )
            if self.terrain_config is not None:
                # Write the terrain heightfield before converting to MJX.
                terrain_data_2d = hfield_data_3d(self.terrain_config)
                self.mj_model.hfield_data[:] = hfield_data_flat_column_major(
                    self.terrain_config, terrain_data_2d
                )
            self.cpu_data = mujoco.MjData(self.mj_model)
            self.mjx_model = mjx.put_model(self.mj_model)
            self.base_data = mjx.put_data(self.mj_model, self.cpu_data)

            def object_id(object_type, name):
                value = mujoco.mj_name2id(
                    self.mj_model, object_type, name
                )
                if value < 0:
                    raise ValueError(f"missing MuJoCo object: {name}")
                return int(value)

            compact_key_id = object_id(
                mujoco.mjtObj.mjOBJ_KEY, "compact"
            )
            self.compact_qpos = jp.asarray(
                self.mj_model.key_qpos[compact_key_id]
            )
            self.compact_ctrl = jp.asarray(
                self.mj_model.key_ctrl[compact_key_id]
            )
            self.action_scales = jp.asarray(task.action_scales)
            reset_qpos, stand_action = reset_pose_arrays_3d(self.mj_model, task)
            self.reset_qpos = jp.asarray(reset_qpos)
            self.stand_action = jp.asarray(stand_action)
            self.planar_compact = jp.asarray(
                (
                    self.geometry_parameters.compact_hip_angle,
                    self.geometry_parameters.compact_knee_angle,
                    self.geometry_parameters.compact_hip_angle,
                    self.geometry_parameters.compact_knee_angle,
                )
            )
            self.planar_action_scales = jp.asarray(PLANAR_ACTION_SCALES)
            self.planar_joint_low = jp.asarray(
                (
                    self.geometry_parameters.hip.shell_compatible_range[0],
                    self.geometry_parameters.knee.shell_compatible_range[0],
                    self.geometry_parameters.hip.shell_compatible_range[0],
                    self.geometry_parameters.knee.shell_compatible_range[0],
                )
            )
            self.planar_joint_high = jp.asarray(
                (
                    self.geometry_parameters.hip.shell_compatible_range[1],
                    self.geometry_parameters.knee.shell_compatible_range[1],
                    self.geometry_parameters.hip.shell_compatible_range[1],
                    self.geometry_parameters.knee.shell_compatible_range[1],
                )
            )

            self.torso_body_id = object_id(
                mujoco.mjtObj.mjOBJ_BODY, "torso"
            )
            self.floor_geom_id = object_id(
                mujoco.mjtObj.mjOBJ_GEOM, "floor"
            )
            (
                self.front_left_foot_geom_id,
                self.front_right_foot_geom_id,
                self.rear_left_foot_geom_id,
                self.rear_right_foot_geom_id,
            ) = (
                object_id(mujoco.mjtObj.mjOBJ_GEOM, name)
                for name in FOOT_GEOM_NAMES_3D
            )
            shell_geom_ids = []
            for geom_id in range(self.mj_model.ngeom):
                name = (
                    mujoco.mj_id2name(
                        self.mj_model, mujoco.mjtObj.mjOBJ_GEOM, geom_id
                    )
                    or ""
                )
                if "_shell_" in name:
                    shell_geom_ids.append(int(geom_id))
            foot_geom_ids = (
                self.front_left_foot_geom_id,
                self.front_right_foot_geom_id,
                self.rear_left_foot_geom_id,
                self.rear_right_foot_geom_id,
            )
            if task.geometry in ROLLINGQUAD_GEOMETRIES_3D and not shell_geom_ids:
                # The corrected URDF integrates the rolling surfaces into the
                # CAD link meshes instead of naming separate analytic shells.
                # Classify non-foot dynamic geoms as shell/body surfaces for
                # rolling contact rewards and diagnostics.
                for geom_id in range(self.mj_model.ngeom):
                    if geom_id in foot_geom_ids:
                        continue
                    if int(self.mj_model.geom_bodyid[geom_id]) != 0:
                        shell_geom_ids.append(int(geom_id))
            self.shell_geom_ids = jp.asarray(shell_geom_ids, dtype=jp.int32)
            self.foot_geom_ids = jp.asarray(
                foot_geom_ids,
                dtype=jp.int32,
            )
            front_leg_names = list(ROLLINGQUAD_FRONT_LEG_GEOM_NAMES_3D)
            rear_leg_names = list(ROLLINGQUAD_REAR_LEG_GEOM_NAMES_3D)
            if task.geometry in PRIMITIVE_ROLLINGQUAD_GEOMETRIES_3D:
                front_leg_names += [
                    "front_left_thigh_motor",
                    "front_right_thigh_motor",
                ]
                rear_leg_names += [
                    "rear_left_thigh_motor",
                    "rear_right_thigh_motor",
                ]
            self.front_leg_geom_ids = jp.asarray(
                [
                    object_id(mujoco.mjtObj.mjOBJ_GEOM, name)
                    for name in front_leg_names
                ]
                if task.geometry in ROLLINGQUAD_GEOMETRIES_3D
                else [],
                dtype=jp.int32,
            )
            self.rear_leg_geom_ids = jp.asarray(
                [
                    object_id(mujoco.mjtObj.mjOBJ_GEOM, name)
                    for name in rear_leg_names
                ]
                if task.geometry in ROLLINGQUAD_GEOMETRIES_3D
                else [],
                dtype=jp.int32,
            )
            if task.geometry in PRIMITIVE_ROLLINGQUAD_GEOMETRIES_3D:
                self.torso_shell_geom_ids = jp.asarray(
                    [
                        int(geom_id)
                        for geom_id in range(self.mj_model.ngeom)
                        if "torso_shell_" in (
                            mujoco.mj_id2name(
                                self.mj_model,
                                mujoco.mjtObj.mjOBJ_GEOM,
                                geom_id,
                            )
                            or ""
                        )
                    ],
                    dtype=jp.int32,
                )
            elif task.geometry in ROLLINGQUAD_GEOMETRIES_3D:
                self.torso_shell_geom_ids = jp.asarray(
                    [object_id(mujoco.mjtObj.mjOBJ_GEOM, "torso_mesh")],
                    dtype=jp.int32,
                )
            else:
                self.torso_shell_geom_ids = jp.asarray([], dtype=jp.int32)

            joint_ids = [
                object_id(mujoco.mjtObj.mjOBJ_JOINT, name)
                for name in JOINT_NAMES_3D
            ]
            self.joint_qpos_indices = jp.asarray(
                [int(self.mj_model.jnt_qposadr[joint_id]) for joint_id in joint_ids]
            )
            self.joint_dof_indices = jp.asarray(
                [int(self.mj_model.jnt_dofadr[joint_id]) for joint_id in joint_ids]
            )
            locked_joint_ids = (
                [
                    mujoco.mj_name2id(
                        self.mj_model,
                        mujoco.mjtObj.mjOBJ_JOINT,
                        f"{leg}_hip_abduction",
                    )
                    for leg in (
                        "front_left",
                        "front_right",
                        "rear_left",
                        "rear_right",
                    )
                ]
                if task.geometry in ("pupper_open60", *ROLLINGQUAD_GEOMETRIES_3D)
                else []
            )
            self.locked_joint_dof_indices = jp.asarray(
                [
                    int(self.mj_model.jnt_dofadr[joint_id])
                    for joint_id in locked_joint_ids
                ],
                dtype=jp.int32,
            )
            self.joint_low = jp.asarray(
                [self.mj_model.jnt_range[joint_id, 0] for joint_id in joint_ids]
            )
            self.joint_high = jp.asarray(
                [self.mj_model.jnt_range[joint_id, 1] for joint_id in joint_ids]
            )
            actuator_ids = [
                object_id(mujoco.mjtObj.mjOBJ_ACTUATOR, f"{name}_servo")
                for name in JOINT_NAMES_3D
            ]
            self.actuator_ids = jp.asarray(actuator_ids, dtype=jp.int32)
            self.force_limits = jp.asarray(
                np.abs(self.mj_model.actuator_forcerange[actuator_ids, 1])
            )
            self.rolling_radius = self.geometry_parameters.shell_contact_radius
            self.root_low_termination_steps = _duration_to_steps(
                task.terminate_root_z_low_duration_s,
                task.control_timestep,
            )
            self.axis_tilt_termination_steps = _duration_to_steps(
                task.terminate_axis_tilt_duration_s,
                task.control_timestep,
            )
            self.forbidden_contact_termination_steps = _duration_to_steps(
                task.terminate_forbidden_contact_duration_s,
                task.control_timestep,
            )
            self.command_interval_steps = _duration_to_steps(
                task.turn_command_interval_s,
                task.control_timestep,
            )
            self.num_command_segments = max(
                1, int(np.ceil(task.episode_length / self.command_interval_steps))
            )

        @property
        def observation_size(self):
            return OBSERVATION_SIZE_3D + (
                PHASE_FEEDBACK_SIZE_3D
                if task.explicit_phase_observation
                else 0
            )

        @property
        def action_size(self):
            return ACTION_SIZE_3D

        @property
        def backend(self):
            return "mjx"

        @property
        def sys(self):
            return self.mjx_model

        @sys.setter
        def sys(self, value):
            self.mjx_model = value

        def _zero_metrics(self):
            zero = jp.zeros((), dtype=jp.float32)
            return {
                "reward": zero,
                "reward_total": zero,
                **{
                    f"reward_{name}": zero
                    for name in REWARD_3D_TERM_NAMES
                },
                "roll_progress_rad": zero,
                "rotation_progress_rad": zero,
                "translation_progress_rad": zero,
                "mismatch_progress_rad": zero,
                "root_x_m": zero,
                "root_y_m": zero,
                "root_z_m": zero,
                "lateral_drift_m": zero,
                "lateral_drift_abs_m": zero,
                "lateral_velocity_m_s": zero,
                "forward_velocity_command": zero,
                "world_forward_velocity_m_s": zero,
                "heading_forward_velocity_m_s": zero,
                "handoff_transition_active": zero,
                "target_forward_velocity_command": zero,
                "target_yaw_rate_command": zero,
                "forward_velocity_m_s": zero,
                "forward_velocity_error_m_s": zero,
                "forward_velocity_error_abs_m_s": zero,
                "yaw_rate_command_rad_s": zero,
                "rolling_axis_heading_rate_rad_s": zero,
                "yaw_rate_error_abs_rad_s": zero,
                "stability_error_cost": zero,
                "axis_tilt_rad": zero,
                "axis_tilt_step_count": zero,
                "root_low_active": zero,
                "root_low_step_count": zero,
                "shell_floor_contact_count": zero,
                "foot_floor_contact_count": zero,
                "same_side_foot_contact_count": zero,
                "same_side_foot_penetration_m": zero,
                "same_side_foot_contact_active": zero,
                "same_side_foot_contact_start": zero,
                "forbidden_contact_count": zero,
                "first_turn_forbidden_contact_count": zero,
                "forbidden_penetration_m": zero,
                "forbidden_contact_step_count": zero,
                "cross_side_foot_contact_count": zero,
                "front_rear_leg_contact_count": zero,
                "front_rear_leg_penetration_m": zero,
                "leg_torso_contact_count": zero,
                "leg_torso_penetration_m": zero,
                "foot_leg_contact_count": zero,
                "foot_leg_penetration_m": zero,
                "foot_foot_contact_count": zero,
                "foot_foot_penetration_m": zero,
                "action_rms": zero,
                "action_rate_rms": zero,
                "startup_action_ramp": zero,
                "stand_startup_active": jp.asarray(task.reset_pose == "stand", dtype=jp.float32),
                "rolling_elapsed_s": zero,
                "normalized_torque_rms": zero,
                "reference_action_rms": zero,
                "residual_action_rms": zero,
                "residual_common_rms": zero,
                "residual_differential_rms": zero,
                "reference_weight": zero,
                "residual_gain": zero,
                "rolling_phase_rad": zero,
                "oscillator_phase_rad": zero,
                "phase_error_rad": zero,
                "oscillator_rate_rad_s": zero,
                "failed": zero,
                "failed_non_lateral": zero,
                "timeout": zero,
                "failure_nonfinite": zero,
                "failure_nonfinite_action": zero,
                "failure_nonfinite_physics": zero,
                "failure_root_low": zero,
                "failure_root_high": zero,
                "failure_lateral_drift": zero,
                "failure_lateral_positive": zero,
                "failure_lateral_negative": zero,
                "failure_axis_tilt": zero,
                "failure_forbidden_depth": zero,
                "failure_forbidden_contact": zero,
            }

        def reset(self, rng, *, seed=None):
            # Evaluation may isolate this salt from the training environment's
            # seed while using exactly the same model and reset implementation.
            rng = jax.random.fold_in(rng, self.seed if seed is None else seed)
            if task.lateral_command_fixed is not None:
                lateral_velocity_command = jp.asarray(
                    task.lateral_command_fixed, dtype=jp.float32
                )
            elif task.lateral_command_enabled:
                command_key = jax.random.fold_in(rng, 777)
                command_uniform = jax.random.uniform(
                    command_key, shape=(), minval=0.0, maxval=1.0
                )
                command_active = (
                    command_uniform < task.lateral_command_probability
                )
                magnitude_key = jax.random.fold_in(rng, 778)
                sign_key = jax.random.fold_in(rng, 779)
                command_magnitude = jax.random.uniform(
                    magnitude_key,
                    shape=(),
                    minval=0.05,
                    maxval=task.lateral_command_max,
                )
                command_sign = jax.random.bernoulli(sign_key, 0.5)
                lateral_velocity_command = (
                    command_active
                    * command_magnitude
                    * (2.0 * command_sign - 1.0)
                )
            else:
                lateral_velocity_command = jp.zeros((), dtype=jp.float32)
            if task.forward_command_fixed_m_s is not None:
                v_cmd_sequence = jp.full(
                    (self.num_command_segments,),
                    task.forward_command_fixed_m_s,
                    dtype=jp.float32,
                )
            elif task.forward_command_enabled:
                forward_key = jax.random.fold_in(rng, 780)
                v_cmd_sequence = jax.random.uniform(
                    forward_key,
                    shape=(self.num_command_segments,),
                    minval=task.forward_command_min_m_s,
                    maxval=task.forward_command_max_m_s,
                )
            else:
                v_cmd_sequence = jp.zeros(
                    (self.num_command_segments,), dtype=jp.float32
                )
            if task.turn_command_fixed_rad_s is not None:
                yaw_cmd_sequence = jp.full(
                    (self.num_command_segments,),
                    task.turn_command_fixed_rad_s,
                    dtype=jp.float32,
                )
            elif task.turn_command_enabled:
                turn_uniform_key = jax.random.fold_in(rng, 781)
                turn_magnitude_key = jax.random.fold_in(rng, 782)
                turn_uniform = jax.random.uniform(
                    turn_uniform_key, shape=(self.num_command_segments,)
                )
                turn_magnitude = jax.random.uniform(
                    turn_magnitude_key,
                    shape=(self.num_command_segments,),
                    minval=task.turn_command_min_rad_s,
                    maxval=task.turn_command_max_rad_s,
                )
                straight_limit = task.turn_command_straight_fraction
                left_limit = (
                    task.turn_command_straight_fraction
                    + task.turn_command_left_fraction
                )
                yaw_cmd_sequence = jp.where(
                    turn_uniform < straight_limit,
                    0.0,
                    jp.where(
                        turn_uniform < left_limit,
                        turn_magnitude,
                        -turn_magnitude,
                    ),
                )
            else:
                yaw_cmd_sequence = jp.zeros(
                    (self.num_command_segments,), dtype=jp.float32
                )
            if (
                task.forward_command_enabled
                or task.forward_command_fixed_m_s is not None
            ):
                scale_sequence = forward_command_to_target_scale_3d(
                    jp, v_cmd_sequence
                )
            else:
                # Command conditioning disabled: keep the reference at its
                # static action scale (default 1.0) instead of scaling it by
                # lookup(0.0)=0.36, which would silently slow every legacy
                # recipe down to ~0.41 m/s.
                scale_sequence = jp.full(
                    (self.num_command_segments,),
                    task.reference_action_scale,
                    dtype=jp.float32,
                )
            prior_sequence = steering_prior_3d(
                jp,
                yaw_cmd_sequence,
                task.turn_command_k_turn,
                task.turn_command_prior_clip,
                residual_gain=reference_settings.residual_gain,
                differential_scale=(
                    1.0
                    if task.residual_pair_differential_scale is None
                    else task.residual_pair_differential_scale
                ),
            )
            if steering_table is not None:
                # Table values are already effective normalized offsets. Do
                # not multiply by residual_gain or differential_scale again.
                prior_sequence = calibrated_steering_prior(
                    jp, steering_table, v_cmd_sequence, yaw_cmd_sequence,
                )
            forward_velocity_command = v_cmd_sequence[0]
            forward_command_scale = scale_sequence[0]
            yaw_rate_command = yaw_cmd_sequence[0]
            steering_prior = prior_sequence[0]
            if task.reset_pair_differential_scale is None:
                joint_key, velocity_key, root_velocity_key = jax.random.split(
                    rng, 3
                )
                tilt_key = jax.random.fold_in(rng, 1)
                joint_noise = jax.random.uniform(
                    joint_key,
                    shape=(ACTION_SIZE_3D,),
                    minval=-task.reset_joint_noise_rad,
                    maxval=task.reset_joint_noise_rad,
                )
                velocity_noise = jax.random.uniform(
                    velocity_key,
                    shape=(self.mj_model.nv,),
                    minval=-task.reset_velocity_noise,
                    maxval=task.reset_velocity_noise,
                )
                root_velocity_noise = jp.zeros((6,), dtype=jp.float32)
                if task.reset_root_velocity_noise > 0.0:
                    root_velocity_noise = jax.random.uniform(
                        root_velocity_key,
                        shape=(6,),
                        minval=-task.reset_root_velocity_noise,
                        maxval=task.reset_root_velocity_noise,
                    )
                velocity_noise = velocity_noise.at[:6].set(
                    root_velocity_noise
                )
                velocity_noise = velocity_noise.at[
                    self.locked_joint_dof_indices
                ].set(0.0)
            else:
                (
                    joint_common_key,
                    joint_differential_key,
                    root_velocity_key,
                    joint_velocity_common_key,
                    joint_velocity_differential_key,
                    tilt_key,
                ) = jax.random.split(rng, 6)
                joint_common_noise = jax.random.uniform(
                    joint_common_key,
                    shape=(ACTION_SIZE_3D // 2,),
                    minval=-task.reset_joint_noise_rad,
                    maxval=task.reset_joint_noise_rad,
                )
                joint_differential_noise = jax.random.uniform(
                    joint_differential_key,
                    shape=(ACTION_SIZE_3D // 2,),
                    minval=-task.reset_joint_noise_rad,
                    maxval=task.reset_joint_noise_rad,
                )
                joint_noise = pair_coupled_reset_noise_3d(
                    jp,
                    joint_common_noise,
                    joint_differential_noise,
                    task.reset_pair_differential_scale,
                )
                root_velocity_noise = jp.zeros((6,), dtype=jp.float32)
                if task.reset_root_velocity_noise > 0.0:
                    root_velocity_noise = jax.random.uniform(
                        root_velocity_key,
                        shape=(6,),
                        minval=-task.reset_root_velocity_noise,
                        maxval=task.reset_root_velocity_noise,
                    )
                joint_velocity_common_noise = jax.random.uniform(
                    joint_velocity_common_key,
                    shape=(ACTION_SIZE_3D // 2,),
                    minval=-task.reset_velocity_noise,
                    maxval=task.reset_velocity_noise,
                )
                joint_velocity_differential_noise = jax.random.uniform(
                    joint_velocity_differential_key,
                    shape=(ACTION_SIZE_3D // 2,),
                    minval=-task.reset_velocity_noise,
                    maxval=task.reset_velocity_noise,
                )
                joint_velocity_noise = pair_coupled_reset_noise_3d(
                    jp,
                    joint_velocity_common_noise,
                    joint_velocity_differential_noise,
                    task.reset_pair_differential_scale,
                )
                velocity_noise = jp.zeros(
                    (self.mj_model.nv,), dtype=jp.float32
                )
                velocity_noise = velocity_noise.at[:6].set(
                    root_velocity_noise
                )
                velocity_noise = velocity_noise.at[
                    self.joint_dof_indices
                ].set(joint_velocity_noise)
            axis_tilt_noise = jax.random.uniform(
                tilt_key,
                shape=(2,),
                minval=-task.reset_axis_tilt_noise_rad,
                maxval=task.reset_axis_tilt_noise_rad,
            )
            oscillator_phase = jp.zeros((), dtype=jp.float32)
            # Steering prior is gated off at reset (rolling_ramp == 0), so the
            # robot starts in the pure stand/compact pose without a tilt.
            cem_action = self._scaled_reference_action_8d(
                oscillator_phase,
                jp.zeros((), dtype=jp.float32),
                forward_command_scale,
            )
            start_ctrl = rolling_target_ctrl_3d(
                jp,
                self.compact_ctrl,
                self.actuator_ids,
                cem_action,
                self.action_scales,
                self.joint_low,
                self.joint_high,
            )
            noisy_start_ctrl = jp.clip(
                start_ctrl[self.actuator_ids] + joint_noise,
                self.joint_low,
                self.joint_high,
            )
            qpos = self.reset_qpos.at[self.joint_qpos_indices].set(
                noisy_start_ctrl
            )
            qpos = qpos.at[0].set(0.0)
            qpos = qpos.at[1].set(0.0)
            qpos = qpos.at[2].set(
                self.reset_qpos[2] + self.terrain_surface_offset
            )
            qpos = qpos.at[3:7].set(
                axis_tilted_quaternion_3d(
                    jp,
                    self.reset_qpos[3:7],
                    axis_tilt_noise[0],
                    axis_tilt_noise[1],
                )
            )
            qvel = velocity_noise
            data = self.base_data.replace(
                qpos=qpos,
                qvel=qvel,
                ctrl=start_ctrl,
            )
            data = mjx.forward(self.mjx_model, data)
            contacts = self._contact_metrics(data)
            axis_tilt = self._rolling_axis_tilt(data, yaw_rate_command)
            body_y_axis, _ = self._body_axes(data)
            initial_stability_cost = stability_error_cost_3d(
                jp,
                reward_settings,
                {
                    "lateral_velocity": data.qvel[1],
                    "lateral_drift": jp.zeros((), dtype=jp.float32),
                    "yaw_rate": data.qvel[5],
                    "yaw": rolling_axis_heading_3d(jp, body_y_axis),
                },
            )
            info = {
                "initial_root_x": data.qpos[0],
                "initial_root_y": data.qpos[1],
                "lateral_velocity_command": lateral_velocity_command,
                "forward_velocity_command": forward_velocity_command,
                "forward_command_scale": forward_command_scale,
                "yaw_rate_command": yaw_rate_command,
                "v_cmd_sequence": v_cmd_sequence,
                "yaw_cmd_sequence": yaw_cmd_sequence,
                "scale_sequence": scale_sequence,
                "prior_sequence": prior_sequence,
                "previous_rolling_axis_heading": rolling_axis_heading_3d(
                    jp, body_y_axis
                ),
                "rolling_axis_heading_rate": jp.zeros((), dtype=jp.float32),
                "previous_root_x": data.qpos[0],
                "previous_root_y": data.qpos[1],
                "cumulative_forward_distance_m": jp.zeros((), dtype=jp.float32),
                "handoff_snapshot": jp.zeros((), dtype=jp.float32),
                "handoff_start_speed": forward_velocity_command,
                "cumulative_rotation": jp.zeros((), dtype=jp.float32),
                "previous_roll_potential": jp.zeros(
                    (), dtype=jp.float32
                ),
                "previous_mismatch_potential": jp.zeros(
                    (), dtype=jp.float32
                ),
                "previous_stability_cost": initial_stability_cost,
                "last_action": cem_action,
                "last_policy_action": jp.zeros(
                    (ACTION_SIZE_3D,), dtype=jp.float32
                ),
                "last_reference_action": cem_action,
                "oscillator_phase": oscillator_phase,
                "rolling_phase": jp.zeros((), dtype=jp.float32),
                "maximum_forbidden_penetration": jp.zeros(
                    (), dtype=jp.float32
                ),
                "maximum_same_side_foot_excess": jp.zeros(
                    (), dtype=jp.float32
                ),
                "previous_same_side_foot_contact": (
                    contacts["same_side_foot_count"] > 0
                ),
                "root_low_step_count": jp.asarray(0, dtype=jp.int32),
                "axis_tilt_step_count": jp.asarray(0, dtype=jp.int32),
                "forbidden_contact_step_count": jp.asarray(
                    0, dtype=jp.int32
                ),
                "step_count": jp.asarray(0, dtype=jp.int32),
            }
            observation = self._observation(
                data,
                cem_action,
                contacts,
                axis_tilt=axis_tilt,
                reference_action_value=cem_action,
                oscillator_phase=oscillator_phase,
                rolling_phase=jp.zeros((), dtype=jp.float32),
                action_ramp=jp.zeros((), dtype=jp.float32),
                lateral_drift=jp.zeros((), dtype=jp.float32),
                lateral_velocity_command=lateral_velocity_command,
                forward_velocity_command=forward_velocity_command,
                yaw_rate_command=yaw_rate_command,
                rolling_axis_heading_rate=jp.zeros((), dtype=jp.float32),
            )
            return State(
                data,
                jp.nan_to_num(observation, nan=0.0, posinf=0.0, neginf=0.0),
                jp.zeros((), dtype=jp.float32),
                jp.zeros((), dtype=jp.float32),
                metrics=self._zero_metrics(),
                info=info,
            )

        def step(self, state, action):
            action_finite = jp.all(jp.isfinite(action))
            raw_policy_action = jp.nan_to_num(
                jp.clip(action, -1.0, 1.0),
                nan=0.0,
                posinf=1.0,
                neginf=-1.0,
            )
            policy_action = (
                raw_policy_action
                if task.direct_effective_action
                else pair_coupled_residual_action_3d(
                    jp,
                    raw_policy_action,
                    task.residual_pair_differential_scale,
                )
            )
            # Optional autonomous-startup wrapper control. Ordinary rolling
            # states have neither override: preserve their original path.
            if "direct_action_override" in state.info:
                policy_action = jp.where(state.info["direct_action_override"],
                                         raw_policy_action, policy_action)
            residual_left = policy_action[jp.asarray((0, 1, 4, 5))]
            residual_right = policy_action[jp.asarray((2, 3, 6, 7))]
            residual_common_rms = jp.sqrt(
                jp.mean(jp.square(0.5 * (residual_left + residual_right)))
            )
            residual_differential_rms = jp.sqrt(
                jp.mean(jp.square(0.5 * (residual_left - residual_right)))
            )
            if (
                not task.direct_effective_action
                and task.lateral_reflex_gain != 0.0
            ):
                lateral_drift = (
                    state.pipeline_state.qpos[1]
                    - state.info["initial_root_y"]
                )
                lateral_velocity = state.pipeline_state.qvel[1]
                lateral_velocity_command = state.info[
                    "lateral_velocity_command"
                ]
                turning = jp.abs(lateral_velocity_command) > 1e-6
                position_gain = jp.where(
                    turning, 0.0, task.lateral_reflex_position_gain
                )
                velocity_error = lateral_velocity - lateral_velocity_command
                reflex_d = jp.clip(
                    position_gain * lateral_drift
                    + task.lateral_reflex_velocity_gain * velocity_error,
                    -1.0,
                    1.0,
                )
                reflex_actuator = task.lateral_reflex_gain * jp.asarray(
                    (
                        reflex_d,
                        0.0,
                        -reflex_d,
                        0.0,
                        reflex_d,
                        0.0,
                        -reflex_d,
                        0.0,
                    )
                )
                policy_action = policy_action + reflex_actuator
            control_dt = (
                float(self.mj_model.opt.timestep) * task.action_repeat
            )
            residual_gain_value = jp.asarray(
                reference_settings.residual_gain, dtype=jp.float32
            )
            reference_weight_value = jp.asarray(
                reference_settings.reference_weight, dtype=jp.float32
            )
            physics_dt = float(self.mj_model.opt.timestep)
            step_count = state.info["step_count"] + 1
            command_index = jp.minimum(
                step_count // self.command_interval_steps,
                self.num_command_segments - 1,
            )
            forward_velocity_command = state.info["v_cmd_sequence"][
                command_index
            ]
            forward_command_scale = state.info["scale_sequence"][
                command_index
            ]
            yaw_rate_command = state.info["yaw_cmd_sequence"][command_index]
            steering_prior = state.info["prior_sequence"][command_index]
            target_forward_command, target_yaw_command = forward_velocity_command, yaw_rate_command
            applied_index = jp.minimum(state.info["step_count"] // self.command_interval_steps,
                                       self.num_command_segments - 1)
            applied_target_forward = state.info["v_cmd_sequence"][applied_index]
            applied_target_yaw = state.info["yaw_cmd_sequence"][applied_index]
            handoff_transition_active = jp.asarray(False)
            if task.handoff_speed_slew_m_s2 > 0:
                from curl_robot_2d_mjx.rolling_speed_tracking import takeover_commands
                ramp_speed, ramp_yaw, _ = takeover_commands(
                    jp, state.info["handoff_start_speed"], target_forward_command,
                    target_yaw_command, step_count * control_dt,
                    task.handoff_speed_slew_m_s2, task.handoff_yaw_slew_rad_s2)
                handoff = state.info["handoff_snapshot"] > 0.5
                forward_velocity_command = jp.where(handoff, ramp_speed, target_forward_command)
                yaw_rate_command = jp.where(handoff, ramp_yaw, target_yaw_command)
                _, _, active_now = takeover_commands(
                    jp, state.info["handoff_start_speed"], applied_target_forward,
                    applied_target_yaw, state.info["step_count"] * control_dt,
                    task.handoff_speed_slew_m_s2, task.handoff_yaw_slew_rad_s2)
                handoff_transition_active = handoff & active_now
            # The actor selected this action using the command in its input.
            # The newly computed command belongs to the next observation.
            applied_forward_command = (state.info["forward_velocity_command"]
                if task.forward_velocity_frame == "heading" else forward_velocity_command)
            applied_yaw_command = (state.info["yaw_rate_command"]
                if task.forward_velocity_frame == "heading" else yaw_rate_command)

            def reference_physics_step(carry, _):
                current_data, current_phase, current_rolling_phase = carry
                controller_time = current_data.time
                if "reference_time_offset" in state.info:
                    controller_time = controller_time + state.info["reference_time_offset"]
                next_phase = advance_oscillator(
                    jp,
                    current_rolling_phase - state.info.get("teacher_phase_offset", 0.),
                    current_phase,
                    physics_dt,
                    reference_settings,
                    rate_scale=task.reference_phase_rate_scale,
                )
                if task.reset_pose == "stand":
                    next_phase = jp.where(
                        current_data.time < task.rolling_start_time_s,
                        current_phase, next_phase,
                    )
                current_reference_action = jp.clip(
                    self._scaled_reference_action_8d(
                        next_phase,
                        controller_time,
                        forward_command_scale,
                    )
                    + rolling_ramp_3d(jp, controller_time, task)
                    * steering_prior,
                    -1.0,
                    1.0,
                )
                current_ramp = smoothstep_ramp(
                    jp,
                    residual_elapsed_3d(jp, controller_time, task),
                    task.startup_action_ramp_s,
                )
                current_action = compose_startup_action_3d(
                    jp, current_reference_action,
                    stand_startup_action_3d(jp, controller_time, self.stand_action, task),
                    policy_action,
                    reference_weight=reference_weight_value,
                    residual_gain=residual_gain_value,
                    ramp=current_ramp,
                    direct=task.direct_effective_action,
                )
                if "direct_action_override" in state.info:
                    current_action = jp.where(state.info["direct_action_override"],
                                              raw_policy_action, current_action)
                current_target = rolling_target_ctrl_3d(
                    jp,
                    self.compact_ctrl,
                    self.actuator_ids,
                    current_action,
                    self.action_scales,
                    self.joint_low,
                    self.joint_high,
                )
                # Deploy DR stores a fixed encoder-zero calibration error in
                # actuator order.  It is added after the policy target is
                # composed so even the four policy-locked abduction motors see
                # the same zero-offset uncertainty as the real controller.
                if "motor_zero_bias_ctrl" in state.info:
                    current_target = jp.clip(
                        current_target + state.info["motor_zero_bias_ctrl"],
                        self.mjx_model.actuator_ctrlrange[:, 0],
                        self.mjx_model.actuator_ctrlrange[:, 1],
                    )
                next_data = mjx.step(
                    self.mjx_model,
                    current_data.replace(ctrl=current_target),
                )
                next_rolling_phase = advance_rolling_phase_3d(
                    jp,
                    current_rolling_phase,
                    next_data.qvel[4],
                    physics_dt,
                )
                phase_rate = (next_phase - current_phase) / physics_dt
                trace = (
                    current_action, current_reference_action, current_ramp, phase_rate,
                )
                if "startup_slip_squared" in state.info:
                    from curl_robot_2d_mjx.compact_startup_3d import data_contact_slip
                    # Sample each solver substep's contact/kinematic state,
                    # rather than missing touchdown/drag within a 20 ms action.
                    trace += data_contact_slip(jp, self.mj_model, next_data,
                                              self.foot_geom_ids, self.floor_geom_id)
                return (
                    next_data,
                    next_phase,
                    next_rolling_phase,
                ), trace

            (
                candidate_data,
                candidate_oscillator_phase,
                candidate_rolling_phase,
            ), reference_trace = jax.lax.scan(
                reference_physics_step,
                (
                    state.pipeline_state,
                    state.info["oscillator_phase"],
                    state.info["rolling_phase"],
                ),
                (),
                length=task.action_repeat,
            )
            effective_action = reference_trace[0][-1]
            cem_action = reference_trace[1][-1]
            action_ramp = reference_trace[2][-1]
            oscillator_rate = reference_trace[3][-1]
            _, _, candidate_contact_distance = self._contact_arrays(
                candidate_data
            )
            physics_finite = (
                jp.all(jp.isfinite(candidate_data.qpos))
                & jp.all(jp.isfinite(candidate_data.qvel))
                & jp.all(jp.isfinite(candidate_data.qacc))
                & jp.all(jp.isfinite(candidate_data.actuator_force))
                & jp.all(jp.isfinite(candidate_data.xpos))
                & jp.all(jp.isfinite(candidate_data.xmat))
                & jp.all(jp.isfinite(candidate_data.site_xpos))
                & jp.all(jp.isfinite(candidate_contact_distance))
            )
            transition_finite = action_finite & physics_finite
            data = jax.lax.cond(
                transition_finite,
                lambda _: candidate_data,
                lambda _: state.pipeline_state,
                operand=None,
            )
            policy_action = jp.where(
                transition_finite,
                policy_action,
                state.info["last_policy_action"],
            )
            effective_action = jp.where(
                transition_finite,
                effective_action,
                state.info["last_action"],
            )
            oscillator_phase = jp.where(
                transition_finite,
                candidate_oscillator_phase,
                state.info["oscillator_phase"],
            )
            rolling_phase = jp.where(
                transition_finite,
                candidate_rolling_phase,
                state.info["rolling_phase"],
            )
            oscillator_rate = jp.where(
                transition_finite,
                oscillator_rate,
                jp.zeros_like(oscillator_rate),
            )
            cem_action = jp.where(
                transition_finite,
                cem_action,
                state.info["last_reference_action"],
            )
            next_reference_action = cem_action
            phase_error = wrapped_phase_error(
                jp, rolling_phase, oscillator_phase
            )
            contacts = self._contact_metrics(data)
            axis_tilt = self._rolling_axis_tilt(data, applied_yaw_command)

            root_x = data.qpos[0]
            root_y = data.qpos[1]
            root_z = data.qpos[2]
            terrain_z = self._terrain_surface_z(root_x)
            root_z_relative = root_z - terrain_z
            body_y_axis, _ = self._body_axes(data)
            lateral_yaw = rolling_axis_heading_3d(jp, body_y_axis)
            from curl_robot_2d_mjx.rolling_speed_tracking import heading_displacement
            dx = root_x - state.info["previous_root_x"]
            dy = root_y - state.info["previous_root_y"]
            along_heading = heading_displacement(
                jp, dx, dy, state.info["previous_rolling_axis_heading"], lateral_yaw)
            distance_step = along_heading if task.forward_velocity_frame == "heading" else dx
            cumulative_forward_distance = state.info["cumulative_forward_distance_m"] + distance_step
            translation_progress = distance_step / self.rolling_radius
            forward_velocity_m_s = distance_step / control_dt
            angular_velocity_y = jp.abs(data.qvel[4])
            rotation_progress = angular_velocity_y * control_dt
            cumulative_rotation = (
                state.info["cumulative_rotation"] + rotation_progress
            )
            cumulative_translation = (cumulative_forward_distance if task.forward_velocity_frame == "heading"
                                      else root_x - state.info["initial_root_x"]) / self.rolling_radius
            roll_potential = conservative_rolling_potential(
                jp, cumulative_rotation, cumulative_translation
            )
            first_turn_active = roll_potential < (2.0 * np.pi)
            conservative_progress = (
                roll_potential - state.info["previous_roll_potential"]
            )
            mismatch_potential = jp.abs(
                cumulative_rotation - cumulative_translation
            )
            mismatch_progress = (
                mismatch_potential
                - state.info["previous_mismatch_potential"]
            )
            backward_progress = jp.maximum(-translation_progress, 0.0)
            lateral_drift = root_y - state.info["initial_root_y"]
            lateral_drift_abs = jp.abs(lateral_drift)
            lateral_velocity = data.qvel[1]
            yaw_rate = data.qvel[5]
            rolling_axis_heading_rate = (
                wrapped_phase_error(
                    jp,
                    lateral_yaw,
                    state.info["previous_rolling_axis_heading"],
                )
                / control_dt
            )
            turning = (
                jp.abs(applied_yaw_command) > 1e-3
            ).astype(jp.float32)
            stability_cost = stability_error_cost_3d(
                jp,
                reward_settings,
                {
                    "lateral_velocity": lateral_velocity,
                    "lateral_drift": lateral_drift,
                    "yaw_rate": yaw_rate,
                    "yaw": lateral_yaw,
                },
            )

            action_rate = jp.mean(
                jp.square(effective_action - state.info["last_action"])
            )
            normalized_torque = data.actuator_force[self.actuator_ids] / jp.maximum(
                self.force_limits, 1e-6
            )
            torque_cost = jp.mean(jp.square(normalized_torque))
            same_side_foot_excess = jp.maximum(
                contacts["same_side_foot_depth"]
                - reward_settings.allowed_foot_penetration_m,
                0.0,
            )
            new_forbidden_max = jp.maximum(
                state.info["maximum_forbidden_penetration"],
                contacts["forbidden_depth"],
            )
            new_same_side_foot_max = jp.maximum(
                state.info["maximum_same_side_foot_excess"],
                same_side_foot_excess,
            )
            forbidden_max_increment = (
                new_forbidden_max
                - state.info["maximum_forbidden_penetration"]
            )
            same_side_foot_max_increment = (
                new_same_side_foot_max
                - state.info["maximum_same_side_foot_excess"]
            )
            same_side_foot_active = contacts["same_side_foot_count"] > 0
            same_side_foot_start = same_side_foot_active & (
                ~state.info["previous_same_side_foot_contact"]
            )
            forbidden_active = contacts["forbidden_count"] > 0
            cross_side_foot_active = contacts["cross_side_foot_count"] > 0

            failure_nonfinite_action = ~action_finite
            failure_nonfinite_physics = action_finite & (~physics_finite)
            failure_nonfinite = ~transition_finite
            if task.terminate_root_z_min is None:
                root_low_active = jp.asarray(False)
                root_low_step_count = jp.asarray(0, dtype=jp.int32)
                failure_root_low = jp.asarray(False)
            else:
                root_low_active = root_z_relative < task.terminate_root_z_min
                root_low_step_count = jp.where(
                    root_low_active,
                    state.info["root_low_step_count"] + 1,
                    jp.asarray(0, dtype=jp.int32),
                )
                failure_root_low = (
                    root_low_step_count >= self.root_low_termination_steps
                )
            axis_tilt_active = axis_tilt > task.terminate_axis_tilt_rad
            axis_tilt_step_count = jp.where(
                axis_tilt_active,
                state.info["axis_tilt_step_count"] + 1,
                jp.asarray(0, dtype=jp.int32),
            )
            forbidden_contact_step_count = jp.where(
                forbidden_active,
                state.info["forbidden_contact_step_count"] + 1,
                jp.asarray(0, dtype=jp.int32),
            )
            failure_axis_tilt = (
                axis_tilt_step_count >= self.axis_tilt_termination_steps
            )
            failure_forbidden_contact = (
                forbidden_contact_step_count
                >= self.forbidden_contact_termination_steps
            )
            failure_root_high = root_z_relative > task.terminate_root_z_max
            lateral_velocity_error = jp.abs(
                lateral_velocity - state.info["lateral_velocity_command"]
            )
            failure_lateral_drift = (
                jp.where(
                    jp.abs(state.info["lateral_velocity_command"]) > 1e-6,
                    lateral_velocity_error > task.lateral_command_error_limit,
                    lateral_drift_abs > task.terminate_lateral_drift_m,
                )
                & (turning < 0.5)
            )
            terminal_lateral_drift = (
                failure_lateral_drift & task.lateral_drift_termination
            )
            failure_forbidden_depth = (
                contacts["forbidden_depth"]
                > task.terminate_forbidden_depth_m
            )
            failed_non_lateral = (
                failure_nonfinite
                | failure_root_low
                | failure_root_high
                | failure_axis_tilt
                | failure_forbidden_depth
                | failure_forbidden_contact
            )
            failed_bool = failed_non_lateral | terminal_lateral_drift
            failure_severe = (
                failure_root_low
                | failure_axis_tilt
                | failure_forbidden_depth
                | failure_forbidden_contact
                | terminal_lateral_drift
            )
            timeout_bool = step_count >= task.episode_length
            done = (failed_bool | timeout_bool).astype(jp.float32)
            remaining_fraction = jp.maximum(
                task.episode_length - step_count, 0
            ).astype(jp.float32) / max(task.episode_length - 1, 1)

            raw_reward_terms = reward_terms_3d(
                jp,
                reward_settings,
                {
                    "conservative_progress": conservative_progress,
                    "mismatch_progress": mismatch_progress,
                    "backward_progress": backward_progress,
                    "forward_velocity": forward_velocity_m_s,
                    "forward_velocity_command": applied_forward_command,
                    "lateral_velocity": lateral_velocity,
                    "lateral_drift": lateral_drift,
                    "yaw_rate": yaw_rate,
                    "yaw": lateral_yaw,
                    "yaw_rate_command": applied_yaw_command,
                    "rolling_axis_heading_rate": rolling_axis_heading_rate,
                    "previous_stability_cost": state.info["previous_stability_cost"],
                    "axis_tilt_squared": jp.square(axis_tilt),
                    "action_rate": action_rate,
                    "residual_action_cost": jp.mean(jp.square(policy_action)),
                    "torque_cost": torque_cost,
                    "control_dt": control_dt,
                    "forbidden_active": forbidden_active.astype(jp.float32),
                    "first_turn_active": first_turn_active.astype(jp.float32),
                    "forbidden_depth": contacts["forbidden_depth"],
                    "forbidden_max_increment": forbidden_max_increment,
                    "same_side_foot_contact_start": (
                        same_side_foot_start.astype(jp.float32)
                    ),
                    "same_side_foot_contact_active": (
                        same_side_foot_active.astype(jp.float32)
                    ),
                    "same_side_foot_excess": same_side_foot_excess,
                    "same_side_foot_max_increment": (
                        same_side_foot_max_increment
                    ),
                    "same_side_foot_gap": contacts["same_side_foot_gap"],
                    "cross_side_foot_contact": (
                        cross_side_foot_active.astype(jp.float32)
                    ),
                    "roll_potential_positive": jp.maximum(
                        roll_potential, 0.0
                    ),
                    "failed": failed_bool.astype(jp.float32),
                    "failure_severe": failure_severe.astype(jp.float32),
                    "failure_nonfinite": failure_nonfinite.astype(
                        jp.float32
                    ),
                    "remaining_fraction": remaining_fraction,
                },
            )
            raw_reward_terms = {
                name: (
                    value
                    if name in ("termination", "early_termination")
                    else jp.where(failure_nonfinite, 0.0, value)
                )
                for name, value in raw_reward_terms.items()
            }
            reward = sum(raw_reward_terms.values())
            reward = jp.nan_to_num(
                reward,
                nan=-reward_settings.nonfinite_termination,
                posinf=-reward_settings.nonfinite_termination,
                neginf=-reward_settings.nonfinite_termination,
            )
            rewards = {
                f"reward_{name}": jp.nan_to_num(
                    value,
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                )
                for name, value in raw_reward_terms.items()
            }
            info = {
                **state.info,
                "forward_velocity_command": forward_velocity_command,
                "forward_command_scale": forward_command_scale,
                "yaw_rate_command": yaw_rate_command,
                "previous_root_x": root_x,
                "previous_root_y": root_y,
                "cumulative_forward_distance_m": cumulative_forward_distance,
                "cumulative_rotation": cumulative_rotation,
                "previous_roll_potential": roll_potential,
                "previous_mismatch_potential": mismatch_potential,
                "previous_stability_cost": stability_cost,
                "last_action": effective_action,
                "last_policy_action": policy_action,
                "last_reference_action": next_reference_action,
                "oscillator_phase": oscillator_phase,
                "rolling_phase": rolling_phase,
                "previous_rolling_axis_heading": lateral_yaw,
                "rolling_axis_heading_rate": rolling_axis_heading_rate,
                "maximum_forbidden_penetration": new_forbidden_max,
                "maximum_same_side_foot_excess": new_same_side_foot_max,
                "previous_same_side_foot_contact": same_side_foot_active,
                "root_low_step_count": root_low_step_count,
                "axis_tilt_step_count": axis_tilt_step_count,
                "forbidden_contact_step_count": (
                    forbidden_contact_step_count
                ),
                "step_count": step_count,
            }
            if "startup_slip_squared" in state.info:
                info.update(startup_slip_squared=jp.mean(reference_trace[4]),
                            startup_slip_distance=physics_dt * jp.sum(reference_trace[5]),
                            startup_slip_peak=jp.max(reference_trace[6]))
            metrics = {
                "reward": reward,
                "reward_total": reward,
                **rewards,
                "roll_progress_rad": conservative_progress,
                "rotation_progress_rad": rotation_progress,
                "translation_progress_rad": translation_progress,
                "mismatch_progress_rad": mismatch_progress,
                "root_x_m": root_x,
                "root_y_m": root_y,
                "root_z_m": root_z,
                "lateral_drift_m": lateral_drift,
                "lateral_drift_abs_m": lateral_drift_abs,
                "lateral_velocity_m_s": lateral_velocity,
                "forward_velocity_command": applied_forward_command,
                "forward_velocity_m_s": forward_velocity_m_s,
                "world_forward_velocity_m_s": dx / control_dt,
                "heading_forward_velocity_m_s": along_heading / control_dt,
                "handoff_transition_active": handoff_transition_active.astype(jp.float32),
                "target_forward_velocity_command": applied_target_forward,
                "target_yaw_rate_command": applied_target_yaw,
                "forward_velocity_error_m_s": (
                    forward_velocity_m_s
                    - applied_forward_command
                ),
                "forward_velocity_error_abs_m_s": jp.abs(
                    forward_velocity_m_s
                    - applied_forward_command
                ),
                "yaw_rate_command_rad_s": applied_yaw_command,
                "rolling_axis_heading_rate_rad_s": rolling_axis_heading_rate,
                "yaw_rate_error_abs_rad_s": jp.abs(
                    rolling_axis_heading_rate
                    - applied_yaw_command
                ),
                "stability_error_cost": stability_cost,
                "axis_tilt_rad": axis_tilt,
                "axis_tilt_step_count": (
                    axis_tilt_step_count.astype(jp.float32)
                ),
                "root_low_active": root_low_active.astype(jp.float32),
                "root_low_step_count": (
                    root_low_step_count.astype(jp.float32)
                ),
                "shell_floor_contact_count": contacts["shell_floor_count"],
                "foot_floor_contact_count": contacts["foot_floor_count"],
                "same_side_foot_contact_count": (
                    contacts["same_side_foot_count"]
                ),
                "same_side_foot_penetration_m": (
                    contacts["same_side_foot_depth"]
                ),
                "same_side_foot_contact_active": (
                    same_side_foot_active.astype(jp.float32)
                ),
                "same_side_foot_contact_start": (
                    same_side_foot_start.astype(jp.float32)
                ),
                "forbidden_contact_count": contacts["forbidden_count"],
                "first_turn_forbidden_contact_count": (
                    contacts["forbidden_count"]
                    * first_turn_active.astype(jp.float32)
                ),
                "forbidden_penetration_m": contacts["forbidden_depth"],
                "forbidden_contact_step_count": (
                    forbidden_contact_step_count.astype(jp.float32)
                ),
                "cross_side_foot_contact_count": (
                    contacts["cross_side_foot_count"]
                ),
                "front_rear_leg_contact_count": (
                    contacts["front_rear_leg_count"]
                ),
                "front_rear_leg_penetration_m": (
                    contacts["front_rear_leg_depth"]
                ),
                "leg_torso_contact_count": contacts["leg_torso_count"],
                "leg_torso_penetration_m": contacts["leg_torso_depth"],
                "foot_leg_contact_count": contacts["foot_leg_count"],
                "foot_leg_penetration_m": contacts["foot_leg_depth"],
                "foot_foot_contact_count": contacts["foot_foot_count"],
                "foot_foot_penetration_m": contacts["foot_foot_depth"],
                "action_rms": jp.sqrt(jp.mean(jp.square(effective_action))),
                "action_rate_rms": jp.sqrt(action_rate),
                "startup_action_ramp": action_ramp,
                "stand_startup_active": (
                    data.time < task.rolling_start_time_s
                ).astype(jp.float32),
                "rolling_elapsed_s": rolling_elapsed_3d(jp, data.time, task),
                "normalized_torque_rms": jp.sqrt(torque_cost),
                "reference_action_rms": jp.sqrt(
                    jp.mean(jp.square(cem_action))
                ),
                "residual_action_rms": jp.sqrt(
                    jp.mean(jp.square(policy_action))
                ),
                "residual_common_rms": residual_common_rms,
                "residual_differential_rms": residual_differential_rms,
                "reference_weight": reference_weight_value,
                "residual_gain": residual_gain_value,
                "rolling_phase_rad": rolling_phase,
                "oscillator_phase_rad": oscillator_phase,
                "phase_error_rad": phase_error,
                "oscillator_rate_rad_s": oscillator_rate,
                "failed": failed_bool.astype(jp.float32),
                "failed_non_lateral": failed_non_lateral.astype(jp.float32),
                "timeout": timeout_bool.astype(jp.float32),
                "failure_nonfinite": failure_nonfinite.astype(jp.float32),
                "failure_nonfinite_action": (
                    failure_nonfinite_action.astype(jp.float32)
                ),
                "failure_nonfinite_physics": (
                    failure_nonfinite_physics.astype(jp.float32)
                ),
                "failure_root_low": failure_root_low.astype(jp.float32),
                "failure_root_high": failure_root_high.astype(jp.float32),
                "failure_lateral_drift": (
                    terminal_lateral_drift.astype(jp.float32)
                ),
                "failure_lateral_positive": (
                    (terminal_lateral_drift & (lateral_drift > 0.0)).astype(
                        jp.float32
                    )
                ),
                "failure_lateral_negative": (
                    (terminal_lateral_drift & (lateral_drift < 0.0)).astype(
                        jp.float32
                    )
                ),
                "failure_axis_tilt": failure_axis_tilt.astype(jp.float32),
                "failure_forbidden_depth": (
                    failure_forbidden_depth.astype(jp.float32)
                ),
                "failure_forbidden_contact": (
                    failure_forbidden_contact.astype(jp.float32)
                ),
            }
            observation = self._observation(
                data,
                effective_action,
                contacts,
                axis_tilt=axis_tilt,
                reference_action_value=next_reference_action,
                oscillator_phase=oscillator_phase,
                rolling_phase=rolling_phase - state.info.get("teacher_phase_offset", 0.),
                action_ramp=action_ramp,
                lateral_drift=lateral_drift,
                lateral_velocity_command=state.info[
                    "lateral_velocity_command"
                ],
                forward_velocity_command=forward_velocity_command,
                yaw_rate_command=yaw_rate_command,
                rolling_axis_heading_rate=rolling_axis_heading_rate,
            )
            metrics = {
                name: jp.nan_to_num(
                    value, nan=0.0, posinf=0.0, neginf=0.0
                )
                for name, value in metrics.items()
            }
            return State(
                data,
                jp.nan_to_num(observation, nan=0.0, posinf=0.0, neginf=0.0),
                reward,
                done,
                metrics=metrics,
                info=info,
            )

        def _reference_action_8d(self, oscillator_phase):
            planar_action = reference_action(
                jp,
                oscillator_phase,
                reference_settings,
                compact_ctrl=self.planar_compact,
                action_scales=self.planar_action_scales,
                joint_low=self.planar_joint_low,
                joint_high=self.planar_joint_high,
                geometry=self.reference_geometry,
            )
            return duplicate_planar_action_3d(jp, planar_action)

        def _scaled_reference_action_8d(
            self,
            oscillator_phase,
            elapsed_s,
            command_scale=None,
        ):
            scale = reference_startup_scale_3d(
                jp,
                rolling_elapsed_3d(jp, elapsed_s, task),
                task,
                target_scale=command_scale,
            )
            return jp.clip(
                stand_startup_action_3d(jp, elapsed_s, self.stand_action, task)
                + scale * self._reference_action_8d(oscillator_phase),
                -1.0,
                1.0,
            )

        def _contact_arrays(self, data):
            contact = data.contact
            if hasattr(contact, "geom1"):
                return contact.geom1, contact.geom2, contact.dist
            return contact.geom[:, 0], contact.geom[:, 1], contact.dist

        def _geom_in_ids(self, geom, ids):
            return jp.any(geom[:, None] == ids[None, :], axis=1)

        def _contact_metrics(self, data):
            geom1, geom2, distance = self._contact_arrays(data)
            valid = (geom1 >= 0) & (geom2 >= 0) & (distance <= 0.0)
            ground = valid & (
                (geom1 == self.floor_geom_id)
                | (geom2 == self.floor_geom_id)
            )
            geom1_foot = self._geom_in_ids(geom1, self.foot_geom_ids)
            geom2_foot = self._geom_in_ids(geom2, self.foot_geom_ids)
            geom1_shell = self._geom_in_ids(geom1, self.shell_geom_ids)
            geom2_shell = self._geom_in_ids(geom2, self.shell_geom_ids)
            geom1_front_leg = self._geom_in_ids(
                geom1, self.front_leg_geom_ids
            )
            geom2_front_leg = self._geom_in_ids(
                geom2, self.front_leg_geom_ids
            )
            geom1_rear_leg = self._geom_in_ids(
                geom1, self.rear_leg_geom_ids
            )
            geom2_rear_leg = self._geom_in_ids(
                geom2, self.rear_leg_geom_ids
            )
            geom1_leg = geom1_front_leg | geom1_rear_leg
            geom2_leg = geom2_front_leg | geom2_rear_leg
            foot_foot = valid & geom1_foot & geom2_foot
            front_rear_leg = valid & (
                (geom1_front_leg & geom2_rear_leg)
                | (geom1_rear_leg & geom2_front_leg)
            )
            leg_torso = valid & (
                (
                    geom1_leg
                    & self._geom_in_ids(geom2, self.torso_shell_geom_ids)
                )
                | (
                    geom2_leg
                    & self._geom_in_ids(geom1, self.torso_shell_geom_ids)
                )
            )
            foot_leg = valid & (
                (geom1_foot & geom2_leg) | (geom2_foot & geom1_leg)
            )
            same_side_foot = valid & (
                _pair_matches(
                    geom1,
                    geom2,
                    self.front_left_foot_geom_id,
                    self.rear_left_foot_geom_id,
                )
                | _pair_matches(
                    geom1,
                    geom2,
                    self.front_right_foot_geom_id,
                    self.rear_right_foot_geom_id,
                )
            )
            cross_side_foot = foot_foot & (~same_side_foot)
            shell_floor = ground & (geom1_shell | geom2_shell)
            foot_floor = ground & (geom1_foot | geom2_foot)
            forbidden = valid & (~ground) & (~same_side_foot)
            foot_diameter = 2.0 * float(self.geometry_parameters.foot_radius)
            same_side_foot_gap = jp.minimum(
                jp.linalg.norm(
                    data.geom_xpos[self.front_left_foot_geom_id]
                    - data.geom_xpos[self.rear_left_foot_geom_id]
                )
                - foot_diameter,
                jp.linalg.norm(
                    data.geom_xpos[self.front_right_foot_geom_id]
                    - data.geom_xpos[self.rear_right_foot_geom_id]
                )
                - foot_diameter,
            )
            return {
                "shell_floor_count": jp.sum(shell_floor).astype(jp.float32),
                "foot_floor_count": jp.sum(foot_floor).astype(jp.float32),
                "same_side_foot_count": jp.sum(same_side_foot).astype(
                    jp.float32
                ),
                "same_side_foot_depth": jp.max(
                    jp.where(same_side_foot, -distance, 0.0)
                ),
                "same_side_foot_gap": same_side_foot_gap,
                "forbidden_count": jp.sum(forbidden).astype(jp.float32),
                "forbidden_depth": jp.max(
                    jp.where(forbidden, -distance, 0.0)
                ),
                "cross_side_foot_count": jp.sum(cross_side_foot).astype(
                    jp.float32
                ),
                "front_rear_leg_count": jp.sum(front_rear_leg).astype(
                    jp.float32
                ),
                "front_rear_leg_depth": jp.max(
                    jp.where(front_rear_leg, -distance, 0.0)
                ),
                "leg_torso_count": jp.sum(leg_torso).astype(jp.float32),
                "leg_torso_depth": jp.max(
                    jp.where(leg_torso, -distance, 0.0)
                ),
                "foot_leg_count": jp.sum(foot_leg).astype(jp.float32),
                "foot_leg_depth": jp.max(
                    jp.where(foot_leg, -distance, 0.0)
                ),
                "foot_foot_count": jp.sum(foot_foot).astype(jp.float32),
                "foot_foot_depth": jp.max(
                    jp.where(foot_foot, -distance, 0.0)
                ),
            }

        def _body_axes(self, data):
            rotation = jp.reshape(data.xmat[self.torso_body_id], (3, 3))
            return rotation[:, 1], rotation[:, 2]

        def _terrain_surface_z(self, root_x):
            if self.terrain_config is None:
                return jp.zeros_like(root_x)
            return terrain_surface_z_xp(jp, root_x, self.terrain_config)

        def _rolling_axis_tilt(self, data, yaw_command=0.):
            body_y_axis, _ = self._body_axes(data)
            return rolling_axis_stability_tilt_3d(
                jp, body_y_axis, yaw_command, calibrated=steering_table is not None,
            )

        def _observation(
            self,
            data,
            last_action,
            contacts,
            *,
            axis_tilt,
            reference_action_value,
            oscillator_phase,
            rolling_phase,
            action_ramp,
            lateral_drift,
            lateral_velocity_command,
            forward_velocity_command,
            yaw_rate_command,
            rolling_axis_heading_rate,
        ):
            body_y_axis, body_z_axis = self._body_axes(data)
            yaw = rolling_axis_heading_3d(jp, body_y_axis)
            rolling_axis_elevation = jp.arcsin(
                jp.clip(jp.abs(body_y_axis[2]), 0.0, 1.0)
            )
            root_position_features = jp.asarray(
                [
                    data.qpos[2] - self._terrain_surface_z(data.qpos[0]),
                    lateral_drift,
                    yaw,
                ]
            )
            root_linear_velocity = data.qvel[:3]
            root_angular_velocity = data.qvel[3:6]
            joint_position = data.qpos[self.joint_qpos_indices]
            joint_velocity = data.qvel[self.joint_dof_indices]
            contact_features = jp.stack(
                (
                    (contacts["shell_floor_count"] > 0).astype(jp.float32),
                    (contacts["foot_floor_count"] > 0).astype(jp.float32),
                    (contacts["same_side_foot_count"] > 0).astype(
                        jp.float32
                    ),
                    (contacts["forbidden_count"] > 0).astype(jp.float32),
                    (contacts["cross_side_foot_count"] > 0).astype(
                        jp.float32
                    ),
                    1000.0 * contacts["same_side_foot_depth"],
                    1000.0 * contacts["forbidden_depth"],
                    axis_tilt,
                )
            )
            observation_parts = (
                    root_position_features,
                    body_y_axis,
                    body_z_axis,
                    root_linear_velocity,
                    root_angular_velocity,
                    joint_position,
                    joint_velocity,
                    last_action,
                    contact_features,
                    reference_settings.reference_weight
                    * reference_action_value,
                    jp.asarray(
                        (
                            reference_settings.reference_weight
                            * jp.sin(oscillator_phase),
                            reference_settings.reference_weight
                            * jp.cos(oscillator_phase),
                            action_ramp,
                            reference_settings.reference_weight,
                            reference_settings.residual_gain,
                        )
                    ),
                    jp.asarray((lateral_velocity_command,)),
                    jp.asarray((forward_velocity_command,)),
                    jp.asarray((yaw_rate_command,)),
                    jp.asarray((rolling_axis_heading_rate,)),
                    jp.asarray((rolling_axis_elevation,)),
                )
            if task.explicit_phase_observation:
                observation_parts += (
                    phase_feedback_observation_3d(
                        jp, rolling_phase, oscillator_phase
                    ),
                )
            return jp.concatenate(observation_parts)

    return CurlRobot3DMJXEnv()


def _duration_to_steps(duration_s: float, control_timestep: float) -> int:
    return max(1, int(np.ceil(duration_s / control_timestep)))


def _pair_matches(geom1, geom2, first_id: int, second_id: int):
    return (
        ((geom1 == first_id) & (geom2 == second_id))
        | ((geom1 == second_id) & (geom2 == first_id))
    )
