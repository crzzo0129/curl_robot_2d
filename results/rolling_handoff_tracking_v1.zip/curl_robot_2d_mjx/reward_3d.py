"""Reward terms for the first 3-D curl rolling MJX environment."""

from __future__ import annotations

from dataclasses import dataclass


REWARD_3D_TERM_NAMES = (
    "roll_progress",
    "roll_mismatch",
    "backward",
    "forward_velocity",
    "lateral_velocity",
    "lateral_drift",
    "yaw_rate",
    "yaw_rate_command",
    "yaw",
    "lateral_velocity_cost",
    "lateral_drift_cost",
    "yaw_rate_cost",
    "yaw_cost",
    "recovery",
    "axis_tilt",
    "action_rate",
    "residual_action",
    "torque",
    "collision",
    "foot_gap",
    "failure_progress_clawback",
    "termination",
    "early_termination",
)


@dataclass(frozen=True)
class Rolling3DRewardConfig:
    progress_clip_rad: float = 0.25
    roll_progress: float = 6.0
    roll_mismatch: float = 0.8
    backward: float = 1.5
    forward_velocity: float = 0.0
    forward_velocity_sigma_m_s: float = 0.10
    turning_forward_velocity_scale: float = 0.0
    lateral_velocity: float = 1.0
    lateral_velocity_sigma_m_s: float = 0.20
    lateral_drift: float = 0.5
    lateral_drift_sigma_m: float = 0.10
    yaw_rate: float = 1.0
    yaw_rate_sigma_rad_s: float = 0.30
    yaw_rate_command: float = 0.0
    yaw_rate_command_sigma_rad_s: float = 0.05
    yaw: float = 0.5
    yaw_sigma_rad: float = 0.10
    lateral_velocity_cost: float = 0.0
    lateral_drift_cost: float = 0.0
    yaw_rate_cost: float = 0.0
    yaw_cost: float = 0.0
    stability_huber_clip: float = 1.0
    recovery: float = 0.0
    recovery_clip: float = 0.25
    axis_tilt: float = 8.0
    action_rate: float = 0.03
    residual_action: float = 0.02
    torque: float = 0.01

    allowed_foot_penetration_m: float = 0.0005
    foot_contact_event: float = 2.0
    foot_contact_time: float = 4.0
    allowed_excess_integral: float = 8000.0
    maximum_allowed_excess: float = 2000.0
    forbidden_contact_time: float = 4.0
    first_turn_forbidden_contact_multiplier: float = 0.0
    forbidden_penetration_integral: float = 20000.0
    maximum_forbidden_penetration: float = 2500.0
    cross_side_foot_contact: float = 30.0
    foot_gap_weight: float = 0.0
    foot_gap_min_m: float = 0.005

    failure_progress_clawback: float = 0.0
    termination: float = 20.0
    severe_extra_termination: float = 20.0
    nonfinite_termination: float = 80.0
    early_termination_scale: float = 1.0


def conservative_rolling_potential(xp, cumulative_rotation, cumulative_translation):
    return xp.minimum(cumulative_rotation, cumulative_translation)


def bounded_huber_cost_3d(xp, value, scale, clip):
    normalized = xp.abs(value) / max(float(scale), 1.0e-6)
    quadratic = xp.minimum(normalized, 1.0)
    cost = 0.5 * xp.square(quadratic) + normalized - quadratic
    return xp.minimum(cost, clip)


def stability_error_cost_terms_3d(xp, config: Rolling3DRewardConfig, inputs):
    return {
        "lateral_velocity_cost": config.lateral_velocity_cost
        * bounded_huber_cost_3d(
            xp,
            inputs["lateral_velocity"],
            config.lateral_velocity_sigma_m_s,
            config.stability_huber_clip,
        ),
        "lateral_drift_cost": config.lateral_drift_cost
        * bounded_huber_cost_3d(
            xp,
            inputs["lateral_drift"],
            config.lateral_drift_sigma_m,
            config.stability_huber_clip,
        ),
        "yaw_rate_cost": config.yaw_rate_cost
        * bounded_huber_cost_3d(
            xp,
            inputs["yaw_rate"],
            config.yaw_rate_sigma_rad_s,
            config.stability_huber_clip,
        ),
        "yaw_cost": config.yaw_cost
        * bounded_huber_cost_3d(
            xp,
            inputs["yaw"],
            config.yaw_sigma_rad,
            config.stability_huber_clip,
        ),
    }


def stability_error_cost_3d(xp, config: Rolling3DRewardConfig, inputs):
    return sum(stability_error_cost_terms_3d(xp, config, inputs).values())


def reward_terms_3d(xp, config: Rolling3DRewardConfig, inputs):
    clipped_progress = xp.clip(
        inputs["conservative_progress"],
        -config.progress_clip_rad,
        config.progress_clip_rad,
    )
    collision_cost = (
        config.forbidden_contact_time
        * inputs["control_dt"]
        * inputs["forbidden_active"]
        * (
            1.0
            + config.first_turn_forbidden_contact_multiplier
            * inputs["first_turn_active"]
        )
        + config.forbidden_penetration_integral
        * inputs["forbidden_depth"]
        * inputs["control_dt"]
        + config.maximum_forbidden_penetration
        * inputs["forbidden_max_increment"]
        + config.foot_contact_event
        * inputs["same_side_foot_contact_start"]
        + config.foot_contact_time
        * inputs["control_dt"]
        * inputs["same_side_foot_contact_active"]
        + config.allowed_excess_integral
        * inputs["same_side_foot_excess"]
        * inputs["control_dt"]
        + config.maximum_allowed_excess
        * inputs["same_side_foot_max_increment"]
        + config.cross_side_foot_contact
        * inputs["cross_side_foot_contact"]
    )
    severe_penalty = config.termination + (
        config.severe_extra_termination * inputs["failure_severe"]
    )
    terminal_penalty = xp.where(
        inputs["failure_nonfinite"] > 0.0,
        config.nonfinite_termination,
        severe_penalty,
    )
    stability_cost_terms = stability_error_cost_terms_3d(xp, config, inputs)
    stability_cost = sum(stability_cost_terms.values())
    recovery_delta = xp.clip(
        inputs["previous_stability_cost"] - stability_cost,
        -config.recovery_clip,
        config.recovery_clip,
    )
    # During a commanded turn, lateral/yaw straight-line stability rewards are
    # suppressed.  Forward-speed tracking may remain at a recipe-selected
    # fraction while the policy tracks the rolling-axis heading rate.
    turning = xp.where(
        xp.abs(inputs["yaw_rate_command"]) > 1e-3, 1.0, 0.0
    )
    not_turning = 1.0 - turning
    return {
        "roll_progress": config.roll_progress * clipped_progress,
        "roll_mismatch": -config.roll_mismatch * inputs["mismatch_progress"],
        "backward": -config.backward * inputs["backward_progress"],
        "forward_velocity": config.forward_velocity
        * (
            not_turning
            + config.turning_forward_velocity_scale * turning
        )
        * xp.exp(
            -xp.square(
                inputs["forward_velocity"]
                - inputs["forward_velocity_command"]
            )
            / config.forward_velocity_sigma_m_s**2
        ),
        "lateral_velocity": config.lateral_velocity * not_turning * xp.exp(
            -xp.square(inputs["lateral_velocity"])
            / config.lateral_velocity_sigma_m_s**2
        ),
        "lateral_drift": config.lateral_drift * not_turning * xp.exp(
            -xp.square(inputs["lateral_drift"])
            / config.lateral_drift_sigma_m**2
        ),
        "yaw_rate": config.yaw_rate * not_turning * xp.exp(
            -xp.square(inputs["yaw_rate"])
            / config.yaw_rate_sigma_rad_s**2
        ),
        "yaw_rate_command": config.yaw_rate_command * turning * xp.exp(
            -xp.square(
                inputs["rolling_axis_heading_rate"]
                - inputs["yaw_rate_command"]
            )
            / config.yaw_rate_command_sigma_rad_s**2
        ),
        "yaw": config.yaw * not_turning * xp.exp(
            -xp.square(inputs["yaw"]) / config.yaw_sigma_rad**2
        ),
        **{
            name: -value
            for name, value in stability_cost_terms.items()
        },
        "recovery": config.recovery * recovery_delta,
        "axis_tilt": -config.axis_tilt * inputs["axis_tilt_squared"],
        "action_rate": -config.action_rate * inputs["action_rate"],
        "residual_action": (
            -config.residual_action * inputs["residual_action_cost"]
        ),
        "torque": -config.torque * inputs["torque_cost"],
        "collision": -collision_cost,
        "foot_gap": config.foot_gap_weight
        * xp.maximum(inputs["same_side_foot_gap"] - config.foot_gap_min_m, 0.0),
        "failure_progress_clawback": (
            -config.failure_progress_clawback
            * inputs["roll_potential_positive"]
            * inputs["failed"]
        ),
        "termination": -terminal_penalty * inputs["failed"],
        "early_termination": (
            -terminal_penalty
            * config.early_termination_scale
            * inputs["remaining_fraction"]
            * inputs["failed"]
        ),
    }
